import os
import re
import base64
import uuid
import zipfile
from datetime import datetime

import pandas as pd
import streamlit as st

try:
    import folium
    from streamlit_folium import st_folium
    HAS_MAP = True
except Exception:
    HAS_MAP = False


# =========================================================
# FİYATCEP - ADİSYON/FİŞ MANTIĞI V1
# =========================================================
# Gerekli dosyalar:
# - products_master_clean.csv
# - source_master.csv
# Opsiyonel:
# - product_specs.csv veya product_specs_template.csv
# - data_reference.csv veya data_reference_template.csv
#
# Not:
# Bu kod kategori/mağaza/marka UYDURMAZ.
# Ekranda görünen ürün ağacı products_master_clean.csv içinden gelir.
# Kaynak listesi source_master.csv içinden gelir.
# Kullanıcı isterse elle kaynak yazabilir; bu kullanıcı girdisidir, otomatik uydurma değildir.
# =========================================================


# =========================================================
# 1. AYARLAR
# =========================================================

PRODUCTS_FILE = "products_master_clean.csv"
SOURCE_FILE = "source_master.csv"

SPECS_FILE = "product_specs.csv"
SPECS_TEMPLATE_FILE = "product_specs_template.csv"

DATA_REFERENCE_FILE = "data_reference.csv"
DATA_REFERENCE_TEMPLATE_FILE = "data_reference_template.csv"

RECEIPT_HEADER_FILE = "receipt_header.csv"
PRICE_RECORDS_FILE = "price_records.csv"
RESEARCH_SESSIONS_FILE = "research_sessions.csv"
SHOPPING_SESSIONS_FILE = "shopping_sessions.csv"
SHOPPING_ITEMS_FILE = "shopping_items.csv"

DATA_PACKAGE_ZIP = "FiyatCep_Data_Paketi_v9.zip"
ICON_MAP_FILE = "icon_map_openmoji.csv"
ICON_DIR = os.path.join("icons", "openmoji")

RECEIPT_HEADER_COLUMNS = [
    "receipt_id",
    "research_id",
    "tarih",
    "saat",
    "source_id",
    "source_type",
    "source_name",
    "konum_lat",
    "konum_lon",
    "konum_dogrulandi",
    "toplam_kalem",
    "not",
]

PRICE_RECORD_COLUMNS = [
    "receipt_id",
    "research_id",
    "line_id",
    "tarih",
    "saat",
    "source_id",
    "source_type",
    "source_name",
    "product_id",
    "urun_adi",
    "marka",
    "model",
    "varyant",
    "birim",
    "fiyat",
    "konum_lat",
    "konum_lon",
    "not",
]

RESEARCH_SESSION_COLUMNS = [
    "research_id",
    "status",
    "mode",
    "baslangic_tarih",
    "baslangic_saat",
    "bitis_tarih",
    "bitis_saat",
    "not",
]

SHOPPING_SESSION_COLUMNS = [
    "shopping_id",
    "research_id",
    "status",
    "tarih",
    "saat",
    "toplam",
    "tasarruf",
    "tamamlanan_urun",
    "toplam_urun",
    "not",
]

SHOPPING_ITEM_COLUMNS = [
    "shopping_id",
    "research_id",
    "product_id",
    "urun",
    "source_name",
    "source_type",
    "fiyat",
    "tasarruf",
    "durum",
    "tarih",
    "saat",
]


st.set_page_config(
    page_title="FiyatCep",
    page_icon="🧾",
    layout="centered",
    initial_sidebar_state="collapsed",
)


# =========================================================
# 2. GENEL YARDIMCI FONKSİYONLAR
# =========================================================

def clean_cell(value):
    if pd.isna(value):
        return ""
    text = str(value).strip()
    if text.lower() in ["nan", "none", "null", "<na>"]:
        return ""
    return text


def normalize_for_search(text):
    text = clean_cell(text).lower()

    tr_map = str.maketrans({
        "ı": "i",
        "İ": "i",
        "ş": "s",
        "ğ": "g",
        "ü": "u",
        "ö": "o",
        "ç": "c",
        "â": "a",
        "î": "i",
        "û": "u",
    })

    text = text.translate(tr_map)
    text = re.sub(r"[^a-z0-9]+", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def compact_join(values, sep=" "):
    output = []
    seen = set()

    for value in values:
        value = clean_cell(value)
        key = normalize_for_search(value)

        if value and key and key not in seen:
            output.append(value)
            seen.add(key)

    return sep.join(output)


def ensure_columns(df, columns):
    for col in columns:
        if col not in df.columns:
            df[col] = ""
    return df


def safe_key(prefix, value, idx=""):
    raw = f"{prefix}_{value}_{idx}"
    return normalize_for_search(raw).replace(" ", "_")[:180]


def parse_price(value):
    value = clean_cell(value)

    if not value:
        return None

    value = value.replace("₺", "").replace("TL", "").replace("tl", "")
    value = value.replace(".", "").replace(",", ".") if "," in value else value

    try:
        price = float(value)
        if price <= 0:
            return None
        return round(price, 2)
    except Exception:
        return None


def format_price(value):
    price = parse_price(value)

    if price is None:
        return ""

    return f"{price:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")



def read_saved_price_records():
    if not os.path.exists(PRICE_RECORDS_FILE):
        return pd.DataFrame(columns=PRICE_RECORD_COLUMNS)

    try:
        df = pd.read_csv(PRICE_RECORDS_FILE, dtype=str, encoding="utf-8-sig")
    except UnicodeDecodeError:
        df = pd.read_csv(PRICE_RECORDS_FILE, dtype=str, encoding="cp1254")
    except Exception:
        return pd.DataFrame(columns=PRICE_RECORD_COLUMNS)

    df = ensure_columns(df, PRICE_RECORD_COLUMNS)

    for col in PRICE_RECORD_COLUMNS:
        df[col] = df[col].apply(clean_cell)

    df["price_float"] = df["fiyat"].apply(parse_price)
    df = df[df["price_float"].notna()].copy()

    return df


def make_current_receipt_df():
    rows = []

    for item in st.session_state.receipt_items:
        rows.append({
            "product_id": clean_cell(item.get("product_id", "")),
            "urun_adi": clean_cell(item.get("urun_adi", "")),
            "title": clean_cell(item.get("title", "")),
            "marka": clean_cell(item.get("marka", "")),
            "model": clean_cell(item.get("model", "")),
            "birim": clean_cell(item.get("birim", "")),
            "path": clean_cell(item.get("path", "")),
        })

    return pd.DataFrame(rows)



def make_saved_receipt_df(saved_df, receipt_id=""):
    if saved_df.empty:
        return pd.DataFrame()

    work = saved_df.copy()

    if receipt_id:
        work = work[work["receipt_id"] == receipt_id].copy()

    if work.empty:
        return pd.DataFrame()

    # Eğer receipt_id verilmediyse en son kaydedilen fişi bul.
    if not receipt_id:
        latest = (
            work.sort_values(["tarih", "saat"], ascending=[False, False])
            .iloc[0]["receipt_id"]
        )
        work = work[work["receipt_id"] == latest].copy()
        st.session_state.compare_receipt_id = latest

    rows = []

    for product_id, group in work.groupby("product_id"):
        first = group.iloc[0]
        rows.append({
            "product_id": clean_cell(first.get("product_id", "")),
            "urun_adi": clean_cell(first.get("urun_adi", "")),
            "title": compact_join([
                first.get("marka", ""),
                first.get("model", ""),
                first.get("urun_adi", ""),
            ]),
            "marka": clean_cell(first.get("marka", "")),
            "model": clean_cell(first.get("model", "")),
            "birim": clean_cell(first.get("birim", "")),
            "path": "",
        })

    return pd.DataFrame(rows)



def get_compare_research_id(saved_df=None):
    research_id = clean_cell(st.session_state.get("active_research_id", ""))

    if research_id:
        return research_id

    research_id = clean_cell(st.session_state.get("compare_research_id", ""))

    if research_id:
        return research_id

    if saved_df is not None and not saved_df.empty and "research_id" in saved_df.columns:
        non_empty = saved_df[saved_df["research_id"] != ""].copy()
        if not non_empty.empty:
            latest = non_empty.sort_values(["tarih", "saat"], ascending=[False, False]).iloc[0]
            return latest["research_id"]

    return ""


def make_research_products_df(saved_df):
    if saved_df.empty:
        return pd.DataFrame()

    rows = []

    for product_id, group in saved_df.groupby("product_id"):
        first = group.sort_values(["tarih", "saat"], ascending=[False, False]).iloc[0]
        rows.append({
            "product_id": clean_cell(first.get("product_id", "")),
            "urun_adi": clean_cell(first.get("urun_adi", "")),
            "title": compact_join([
                first.get("marka", ""),
                first.get("model", ""),
                first.get("urun_adi", ""),
            ]),
            "marka": clean_cell(first.get("marka", "")),
            "model": clean_cell(first.get("model", "")),
            "birim": clean_cell(first.get("birim", "")),
            "path": "",
        })

    return pd.DataFrame(rows)


def compute_cheapest_plan(current_df, saved_df):
    """
    Aktif fiyat araştırmasındaki kayıtlar üzerinden:
    - ürün bazında en ucuz kaynak
    - ürün bazında en yüksek kaynak
    - tahmini tasarruf
    - kaynak/durak bazında rota bölümleri
    üretir.
    """
    if current_df.empty or saved_df.empty:
        return pd.DataFrame(), pd.DataFrame(), pd.DataFrame()

    current_ids = current_df["product_id"].dropna().astype(str).tolist()
    relevant = saved_df[saved_df["product_id"].isin(current_ids)].copy()

    if relevant.empty:
        return pd.DataFrame(), pd.DataFrame(), pd.DataFrame()

    relevant = relevant.sort_values(["product_id", "price_float", "tarih", "saat"], ascending=[True, True, False, False])

    cheapest_rows = []

    for product_id, group in relevant.groupby("product_id"):
        product_info = current_df[current_df["product_id"] == product_id].iloc[0].to_dict()

        best = group.sort_values(["price_float", "tarih", "saat"], ascending=[True, False, False]).iloc[0].to_dict()
        worst = group.sort_values(["price_float", "tarih", "saat"], ascending=[False, False, False]).iloc[0].to_dict()

        best_price = float(best.get("price_float", 0))
        worst_price = float(worst.get("price_float", best_price))
        saving = max(0.0, worst_price - best_price)

        cheapest_rows.append({
            "product_id": product_id,
            "urun": product_info.get("title") or product_info.get("urun_adi"),
            "birim": product_info.get("birim", ""),
            "path": product_info.get("path", ""),
            "en_ucuz_fiyat": round(best_price, 2),
            "en_yuksek_fiyat": round(worst_price, 2),
            "tasarruf": round(saving, 2),
            "source_name": best.get("source_name", ""),
            "source_type": best.get("source_type", ""),
            "tarih": best.get("tarih", ""),
            "saat": best.get("saat", ""),
            "worst_source_name": worst.get("source_name", ""),
            "worst_source_type": worst.get("source_type", ""),
        })

    cheapest_df = pd.DataFrame(cheapest_rows)

    # Aynı ürün master datada birden fazla product_id ile geçiyorsa
    # rotada iki ayrı kutu olarak görünmesin.
    # Örn: Biber Çarliston farklı product_id'lerle kayıtlıysa,
    # rota için tek ürün kabul edilir ve en ucuz fiyat seçilir.
    if not cheapest_df.empty:
        cheapest_df["_route_key"] = cheapest_df.apply(
            lambda row: normalize_for_search(
                compact_join([
                    row.get("urun", ""),
                    row.get("birim", ""),
                ])
            ),
            axis=1
        )

        collapsed_rows = []

        for _, dup_group in cheapest_df.groupby("_route_key"):
            dup_group = dup_group.copy()

            best = dup_group.sort_values(
                ["en_ucuz_fiyat", "tarih", "saat"],
                ascending=[True, False, False]
            ).iloc[0].to_dict()

            max_price = float(dup_group["en_yuksek_fiyat"].max())
            min_price = float(dup_group["en_ucuz_fiyat"].min())

            best["en_yuksek_fiyat"] = round(max_price, 2)
            best["tasarruf"] = round(max(0.0, max_price - min_price), 2)

            collapsed_rows.append(best)

        cheapest_df = pd.DataFrame(collapsed_rows).drop(columns=["_route_key"], errors="ignore")

    stop_rows = []
    if not cheapest_df.empty:
        for source_name, group in cheapest_df.groupby("source_name"):
            stop_rows.append({
                "source_name": source_name,
                "source_type": compact_join(group["source_type"].dropna().unique(), sep=", "),
                "urun_sayisi": len(group),
                "toplam": round(float(group["en_ucuz_fiyat"].sum()), 2),
                "tasarruf": round(float(group["tasarruf"].sum()), 2),
                "urunler": " | ".join(group["urun"].astype(str).tolist()),
            })

    stop_df = pd.DataFrame(stop_rows)
    if not stop_df.empty:
        stop_df = stop_df.sort_values(["toplam", "urun_sayisi"], ascending=[True, False])

    single_stop_rows = []
    for source_name, group in relevant.groupby("source_name"):
        best_per_product = group.sort_values("price_float").groupby("product_id").head(1)
        single_stop_rows.append({
            "source_name": source_name,
            "source_type": compact_join(best_per_product["source_type"].dropna().unique(), sep=", "),
            "bulunan_urun": best_per_product["product_id"].nunique(),
            "toplam_urun": len(current_df),
            "eksik_urun": len(current_df) - best_per_product["product_id"].nunique(),
            "toplam": round(float(best_per_product["price_float"].sum()), 2),
        })

    single_stop_df = pd.DataFrame(single_stop_rows)

    if not single_stop_df.empty:
        single_stop_df = single_stop_df.sort_values(
            ["eksik_urun", "toplam", "bulunan_urun"],
            ascending=[True, True, False]
        )

    return cheapest_df, stop_df, single_stop_df

def format_product_title(row):
    marka = clean_cell(row.get("marka", ""))
    model = clean_cell(row.get("model", ""))
    urun_adi = clean_cell(row.get("urun_adi", ""))

    base = model or urun_adi or marka

    if not base:
        base = urun_adi

    if marka and normalize_for_search(marka) not in normalize_for_search(base):
        base = compact_join([marka, base])

    words = base.split()

    if len(words) % 2 == 0:
        half = len(words) // 2
        if [w.lower() for w in words[:half]] == [w.lower() for w in words[half:]]:
            base = " ".join(words[:half])

    if marka.lower() == "apple":
        base = re.sub(r"\b[A-Z0-9]{4,}TU/A\b", "", base)
        base = re.sub(r"\bM[A-Z0-9]{3,}/A\b", "", base)
        base = re.sub(r"\b[A-Z0-9]{6,}/A\b", "", base)

    base = re.sub(r"\s+", " ", base).strip()

    if len(base) > 120:
        base = base[:117] + "..."

    return base or "İsimsiz Ürün"


def format_product_subtitle(row):
    return compact_join([
        row.get("sektor", ""),
        row.get("ana_kategori", ""),
        row.get("alt_kategori", ""),
        row.get("urun_turu", ""),
    ], sep=" > ")


def get_today_strings():
    now = datetime.now()
    return now.strftime("%Y-%m-%d"), now.strftime("%H:%M:%S")


def append_csv(file_path, rows, columns):
    if not rows:
        return

    df_new = pd.DataFrame(rows)
    df_new = ensure_columns(df_new, columns)[columns]

    if os.path.exists(file_path):
        try:
            df_old = pd.read_csv(file_path, dtype=str, encoding="utf-8-sig")
            all_cols = list(dict.fromkeys(list(df_old.columns) + columns))

            df_old = ensure_columns(df_old, all_cols)
            df_new = ensure_columns(df_new, all_cols)

            df_out = pd.concat([df_old[all_cols], df_new[all_cols]], ignore_index=True)

        except Exception:
            df_out = df_new
    else:
        df_out = df_new

    df_out.to_csv(file_path, index=False, encoding="utf-8-sig")


# =========================================================
# 3. DOSYA OKUMA
# =========================================================


def read_research_sessions():
    if not os.path.exists(RESEARCH_SESSIONS_FILE):
        return pd.DataFrame(columns=RESEARCH_SESSION_COLUMNS)

    try:
        df = pd.read_csv(RESEARCH_SESSIONS_FILE, dtype=str, encoding="utf-8-sig")
    except UnicodeDecodeError:
        df = pd.read_csv(RESEARCH_SESSIONS_FILE, dtype=str, encoding="cp1254")
    except Exception:
        return pd.DataFrame(columns=RESEARCH_SESSION_COLUMNS)

    df = ensure_columns(df, RESEARCH_SESSION_COLUMNS)

    for col in RESEARCH_SESSION_COLUMNS:
        df[col] = df[col].apply(clean_cell)

    return df[RESEARCH_SESSION_COLUMNS]


def write_research_sessions(df):
    df = ensure_columns(df, RESEARCH_SESSION_COLUMNS)[RESEARCH_SESSION_COLUMNS]
    df.to_csv(RESEARCH_SESSIONS_FILE, index=False, encoding="utf-8-sig")


def upsert_research_session(row):
    df = read_research_sessions()

    if df.empty or row["research_id"] not in df["research_id"].tolist():
        df = pd.concat([df, pd.DataFrame([row])], ignore_index=True)
    else:
        idx = df.index[df["research_id"] == row["research_id"]][0]
        for key, value in row.items():
            if key in df.columns:
                df.at[idx, key] = value

    write_research_sessions(df)


def start_research_session(mode="Bugün alacağım"):
    tarih, saat = get_today_strings()
    research_id = "AR_" + datetime.now().strftime("%Y%m%d%H%M%S") + "_" + uuid.uuid4().hex[:5]

    row = {
        "research_id": research_id,
        "status": "açık",
        "mode": mode,
        "baslangic_tarih": tarih,
        "baslangic_saat": saat,
        "bitis_tarih": "",
        "bitis_saat": "",
        "not": "",
    }

    upsert_research_session(row)

    st.session_state.active_research_id = research_id
    st.session_state.active_research_mode = mode
    st.session_state.research_active = True
    st.session_state.compare_research_id = research_id
    st.session_state.current_shopping_id = ""
    st.session_state.shopping_checked = {}
    st.session_state.step = "product_tree"


def finish_research_session():
    research_id = clean_cell(st.session_state.get("active_research_id", ""))

    if not research_id:
        st.warning("Açık fiyat araştırması yok.")
        return

    sessions = read_research_sessions()
    current = sessions[sessions["research_id"] == research_id]

    tarih, saat = get_today_strings()

    if current.empty:
        row = {
            "research_id": research_id,
            "status": "kapalı",
            "mode": st.session_state.get("active_research_mode", ""),
            "baslangic_tarih": "",
            "baslangic_saat": "",
            "bitis_tarih": tarih,
            "bitis_saat": saat,
            "not": "",
        }
    else:
        row = current.iloc[0].to_dict()
        row["status"] = "kapalı"
        row["bitis_tarih"] = tarih
        row["bitis_saat"] = saat

    upsert_research_session(row)

    st.session_state.research_active = False
    st.session_state.compare_research_id = research_id
    st.session_state.active_research_id = ""
    st.session_state.active_research_mode = ""
    st.session_state.step = "compare_prices"


def load_open_research_into_state():
    if st.session_state.get("research_active", False):
        return

    sessions = read_research_sessions()

    if sessions.empty:
        return

    open_sessions = sessions[sessions["status"] == "açık"].copy()

    if open_sessions.empty:
        return

    open_sessions = open_sessions.sort_values(
        ["baslangic_tarih", "baslangic_saat"],
        ascending=[False, False]
    )

    row = open_sessions.iloc[0]

    st.session_state.active_research_id = row["research_id"]
    st.session_state.active_research_mode = row["mode"]
    st.session_state.research_active = True
    st.session_state.compare_research_id = row["research_id"]



def read_csv_smart(file_name):
    """
    Önce FiyatCep_Data_Paketi_v8.zip içindeki güncel dosyayı okur.
    Böylece klasörde eski products_master_clean.csv kalmışsa menüyü bozmaz.
    Zip yoksa aynı klasördeki CSV'ye düşer.
    """

    if os.path.exists(DATA_PACKAGE_ZIP):
        try:
            with zipfile.ZipFile(DATA_PACKAGE_ZIP) as z:
                if file_name in z.namelist():
                    with z.open(file_name) as f:
                        return pd.read_csv(f, dtype=str, encoding="utf-8-sig")
        except Exception as e:
            st.error(f"{DATA_PACKAGE_ZIP} içinden {file_name} okunamadı: {e}")
            return pd.DataFrame()

    if os.path.exists(file_name):
        try:
            return pd.read_csv(file_name, dtype=str, encoding="utf-8-sig")
        except UnicodeDecodeError:
            return pd.read_csv(file_name, dtype=str, encoding="cp1254")
        except Exception as e:
            st.error(f"{file_name} okunamadı: {e}")
            return pd.DataFrame()

    return pd.DataFrame()


@st.cache_data
def load_products():
    df = read_csv_smart(PRODUCTS_FILE)

    required = [
        "product_id",
        "sektor",
        "ana_kategori",
        "alt_kategori",
        "urun_turu",
        "marka",
        "model",
        "urun_adi",
        "birim",
        "icon",
        "photo_thumb_path",
        "photo_detail_path",
        "ui_seviye_1",
        "ui_seviye_2",
        "ui_seviye_3",
        "ui_seviye_4",
        "ui_seviye_5",
        "ui_path",
    ]

    df = ensure_columns(df, required)

    for col in required:
        df[col] = df[col].apply(clean_cell)

    # ui seviyeleri boşsa temel kolonlardan doldur.
    df["ui_seviye_1"] = df["ui_seviye_1"].where(df["ui_seviye_1"] != "", df["sektor"])
    df["ui_seviye_2"] = df["ui_seviye_2"].where(df["ui_seviye_2"] != "", df["ana_kategori"])
    df["ui_seviye_3"] = df["ui_seviye_3"].where(df["ui_seviye_3"] != "", df["alt_kategori"])
    df["ui_seviye_4"] = df["ui_seviye_4"].where(df["ui_seviye_4"] != "", df["urun_turu"])
    df["ui_seviye_5"] = df["ui_seviye_5"].where(df["ui_seviye_5"] != "", df["marka"])

    # Tamamen boş seviyeleri normalize et.
    for col in ["ui_seviye_1", "ui_seviye_2", "ui_seviye_3", "ui_seviye_4", "ui_seviye_5"]:
        df[col] = df[col].apply(clean_cell)

    df = df[df["product_id"] != ""]
    df = df[df["urun_adi"] != ""]
    df = df.drop_duplicates(subset=["product_id"], keep="first").reset_index(drop=True)

    search_cols = [
        "product_id",
        "sektor",
        "ana_kategori",
        "alt_kategori",
        "urun_turu",
        "marka",
        "model",
        "urun_adi",
        "birim",
        "ui_path",
    ]

    df["search_text"] = (
        df[search_cols]
        .fillna("")
        .astype(str)
        .agg(" ".join, axis=1)
        .apply(normalize_for_search)
    )

    return df


@st.cache_data
def load_sources():
    df = read_csv_smart(SOURCE_FILE)

    required = [
        "source_id",
        "source_type",
        "source_name",
        "related_brand",
        "sector_scope",
        "category_scope",
        "product_count",
        "is_brand_store",
        "is_user_created",
        "note",
    ]

    df = ensure_columns(df, required)

    for col in required:
        df[col] = df[col].apply(clean_cell)

    df = df[df["source_name"] != ""]
    df = df.drop_duplicates(subset=["source_id", "source_type", "source_name"], keep="first")
    df = df.reset_index(drop=True)

    return df


@st.cache_data
def load_specs():
    df = read_csv_smart(SPECS_FILE)

    if df.empty:
        df = read_csv_smart(SPECS_TEMPLATE_FILE)

    required = ["product_id", "ozellik_adi", "ozellik_degeri", "note"]
    df = ensure_columns(df, required)

    for col in required:
        df[col] = df[col].apply(clean_cell)

    df = df[
        (df["product_id"] != "") &
        (df["ozellik_adi"] != "") &
        (df["ozellik_degeri"] != "")
    ]

    return df[required].drop_duplicates().reset_index(drop=True)


@st.cache_data
def load_reference():
    df = read_csv_smart(DATA_REFERENCE_FILE)

    if df.empty:
        df = read_csv_smart(DATA_REFERENCE_TEMPLATE_FILE)

    required = [
        "product_id",
        "veri_kaynak_adi",
        "referans_fiyat",
        "para_birimi",
        "urun_linki",
        "gorsel_linki",
        "note",
    ]

    df = ensure_columns(df, required)

    for col in required:
        df[col] = df[col].apply(clean_cell)

    df = df[df["product_id"] != ""]

    return df[required].reset_index(drop=True)


products_df = load_products()
sources_df = load_sources()
specs_df = load_specs()
reference_df = load_reference()


# =========================================================
# 4. ÜRÜN / KAYNAK FONKSİYONLARI
# =========================================================

LEVEL_COLS = [
    "ui_seviye_1",
    "ui_seviye_2",
    "ui_seviye_3",
    "ui_seviye_4",
    "ui_seviye_5",
]

TREE_OPTION_ORDER = {
    "ui_seviye_1": ["Gıda", "Elektronik", "Temizlik"],
    "gida_ui_seviye_2": [
        "Meyve Sebze",
        "Kuru Gıda",
        "Şarküteri",
        "Et Tavuk Balık",
    ],
    "meyve_sebze_ui_seviye_3": [
        "Sebzeler",
        "Meyveler",
    ],
    "kuru_gida_ui_seviye_3": [
        "Kuru Bakliyat",
        "Temel Gıda",
        "Baharat",
        "Kuruyemiş",
        "İçecekler",
        "Paketli Gıda",
    ],
    "elektronik_ui_seviye_2": [
        "Telefon",
        "Bilgisayar & Tablet",
        "Beyaz Eşya & Ev Aletleri",
        "Ev & Yaşam",
        "Ağız & Diş Bakımı",
        "Saç Bakım Cihazları",
        "Tıraş & Epilasyon",
        "Kişisel Bakım",
    ],
    "bilgisayar_ui_seviye_3": [
        "Masaüstü/PC",
        "Dizüstü/Laptop",
        "Tablet",
        "Monitör",
        "Diğerleri",
    ],
}

PRODUCT_ORDER = {
    "sebzeler": [
        "domates",
        "patates",
        "salatalik",
        "taze sogan",
        "limon",
        "biber",
        "patlican",
        "pirasa",
        "havuc",
        "roka",
        "kivircik",
        "maydanoz",
        "sarmisak",
        "sarimsak",
    ],
    "meyveler": [
        "elma",
        "armut",
        "portakal",
        "ayva",
        "karpuz",
        "cilek",
        "erik",
        "kiraz",
        "nar",
    ],
}

def product_order_score(row):
    level_1 = clean_cell(st.session_state.get("level_1", ""))
    level_2 = clean_cell(st.session_state.get("level_2", ""))
    level_3 = clean_cell(st.session_state.get("level_3", ""))

    if level_1 != "Gıda" or level_2 != "Meyve Sebze":
        return 9999

    name = normalize_for_search(row.get("urun_adi", ""))

    if level_3 == "Sebzeler":
        order = PRODUCT_ORDER["sebzeler"]
    elif level_3 == "Meyveler":
        order = PRODUCT_ORDER["meyveler"]
    else:
        return 9999

    for i, key in enumerate(order):
        key_norm = normalize_for_search(key)

        if name == key_norm:
            return i * 100

        if name.startswith(key_norm + " ") or key_norm in name:
            return i * 100 + 10

        if key_norm == "taze sogan" and ("sogan taze" in name or "taze sogan" in name):
            return i * 100

    return 9999

def sort_tree_options(options, level_col):
    options = [clean_cell(x) for x in options if clean_cell(x)]

    if level_col == "ui_seviye_1":
        order = TREE_OPTION_ORDER["ui_seviye_1"]
    elif level_col == "ui_seviye_2" and st.session_state.get("level_1") == "Gıda":
        order = TREE_OPTION_ORDER["gida_ui_seviye_2"]
    elif level_col == "ui_seviye_3" and st.session_state.get("level_1") == "Gıda" and st.session_state.get("level_2") == "Meyve Sebze":
        order = TREE_OPTION_ORDER["meyve_sebze_ui_seviye_3"]
    elif level_col == "ui_seviye_3" and st.session_state.get("level_1") == "Gıda" and st.session_state.get("level_2") == "Kuru Gıda":
        order = TREE_OPTION_ORDER["kuru_gida_ui_seviye_3"]
    elif level_col == "ui_seviye_2" and st.session_state.get("level_1") == "Elektronik":
        order = TREE_OPTION_ORDER["elektronik_ui_seviye_2"]
    elif level_col == "ui_seviye_3" and st.session_state.get("level_1") == "Elektronik" and st.session_state.get("level_2") == "Bilgisayar & Tablet":
        order = TREE_OPTION_ORDER["bilgisayar_ui_seviye_3"]
    else:
        order = []

    order_map = {name: i for i, name in enumerate(order)}

    return sorted(
        options,
        key=lambda x: (order_map.get(x, 999), normalize_for_search(x))
    )


def get_filtered_products():
    df = products_df.copy()

    for i, col in enumerate(LEVEL_COLS, start=1):
        selected = clean_cell(st.session_state.get(f"level_{i}", ""))
        if selected:
            df = df[df[col] == selected]

    return df


def get_next_level_options():
    df = get_filtered_products()

    for i, col in enumerate(LEVEL_COLS, start=1):
        selected = clean_cell(st.session_state.get(f"level_{i}", ""))
        if not selected:
            options = [
                clean_cell(x)
                for x in df[col].dropna().unique()
                if clean_cell(x)
            ]
            options = sort_tree_options(options, col)
            return i, col, options

    return None, None, []


def reset_tree(from_level=1):
    for i in range(from_level, 6):
        st.session_state[f"level_{i}"] = ""

    st.session_state.product_list_limit = 12


def get_deepest_selected_level():
    deepest = 0

    for i in range(1, 6):
        if clean_cell(st.session_state.get(f"level_{i}", "")):
            deepest = i

    return deepest


def go_up_one_level():
    deepest = get_deepest_selected_level()

    if deepest <= 1:
        reset_tree(1)
    else:
        reset_tree(deepest)


def get_icon_map():
    """
    icon_map_openmoji.csv varsa ürün ikonlarını oradan okur.
    Dosya yoksa ürün adına/kategoriye göre emoji fallback üretir.
    """
    if not os.path.exists(ICON_MAP_FILE):
        return {}

    try:
        df = pd.read_csv(ICON_MAP_FILE, dtype=str, encoding="utf-8-sig").fillna("")
    except UnicodeDecodeError:
        df = pd.read_csv(ICON_MAP_FILE, dtype=str, encoding="cp1254").fillna("")
    except Exception:
        return {}

    if "product_id" not in df.columns:
        return {}

    records = {}
    for _, row in df.iterrows():
        pid = clean_cell(row.get("product_id", ""))
        if not pid:
            continue
        records[pid] = {
            "icon_file": clean_cell(row.get("icon_file", "")),
            "emoji": clean_cell(row.get("emoji_fallback", "")),
            "icon_id": clean_cell(row.get("icon_id", "")),
        }

    return records


@st.cache_data(show_spinner=False)
def cached_icon_map():
    return get_icon_map()


def infer_icon_emoji(text):
    n = normalize_for_search(text)

    rules = [
        (["domates", "tomato"], "🍅"),
        (["patates", "potato"], "🥔"),
        (["salatalik", "hiyar", "cucumber"], "🥒"),
        (["taze sogan", "sogan", "onion"], "🧅"),
        (["limon", "lemon"], "🍋"),
        (["biber", "pepper", "kapya", "carliston"], "🌶️"),
        (["patlican", "eggplant"], "🍆"),
        (["pirasa", "leek"], "🥬"),
        (["havuc", "carrot"], "🥕"),
        (["roka", "kivircik", "marul", "lettuce"], "🥬"),
        (["maydanoz", "parsley", "herb"], "🌿"),
        (["sarimsak", "sarmisak", "garlic"], "🧄"),
        (["elma", "apple"], "🍎"),
        (["armut", "pear"], "🍐"),
        (["portakal", "orange"], "🍊"),
        (["karpuz", "watermelon"], "🍉"),
        (["cilek", "strawberry"], "🍓"),
        (["erik", "plum"], "🟣"),
        (["kiraz", "cherry"], "🍒"),
        (["nar", "pomegranate"], "🔴"),
        (["ayva"], "🍐"),
        (["sut", "milk"], "🥛"),
        (["yogurt", "yoğurt"], "🥛"),
        (["peynir", "cheese"], "🧀"),
        (["yumurta", "egg"], "🥚"),
        (["et", "kıyma", "kiyma"], "🥩"),
        (["tavuk", "chicken"], "🍗"),
        (["balik", "fish"], "🐟"),
        (["ekmek", "bread"], "🍞"),
        (["makarna", "pasta"], "🍝"),
        (["pirinc", "rice"], "🍚"),
        (["bulgur", "mercimek", "fasulye", "nohut", "bakliyat"], "🫘"),
        (["baharat", "kekik", "nane", "kimyon", "pul biber"], "🧂"),
        (["cay", "tea"], "🍵"),
        (["kahve", "coffee"], "☕"),
        (["su ", "su"], "💧"),
        (["telefon", "iphone", "samsung", "xiaomi", "tecno", "vivo", "smartphone"], "📱"),
        (["laptop", "notebook", "macbook", "dizustu"], "💻"),
        (["tablet"], "📱"),
        (["monitor"], "🖥️"),
        (["buzdolabi", "buzdolabı"], "🧊"),
        (["camasir makinesi", "çamaşır makinesi"], "🧺"),
        (["bulasik makinesi", "bulaşık makinesi"], "🍽️"),
        (["firin", "fırın", "mikrodalga"], "🔥"),
        (["supurge", "süpürge", "vacuum", "dreame"], "🧹"),
        (["utu", "ütü"], "♨️"),
        (["airfryer", "fritoz"], "🍟"),
        (["mikser", "blender", "rondo", "mutfak robotu", "mutfak sefi"], "🥣"),
        (["kettle", "su isiticisi", "cay makinesi"], "☕"),
        (["dis fircasi", "diş fırçası", "agiz", "ağız"], "🪥"),
        (["tras", "tıraş", "epilasyon"], "🪒"),
        (["sampuan", "şampuan", "sabun"], "🧴"),
        (["deterjan", "temizleyici", "camasir suyu", "çamaşır suyu", "yumusatici"], "🧴"),
        (["tuvalet kagidi", "kağıt havlu", "pecete"], "🧻"),
        (["akaryakit", "benzin", "motorin", "lpg"], "⛽"),
    ]

    for keys, emoji in rules:
        if any(k in n for k in keys):
            return emoji

    if "gida" in n or "meyve" in n or "sebze" in n:
        return "🛒"
    if "elektronik" in n:
        return "🔌"
    if "temizlik" in n:
        return "🧽"

    return "🛒"


def get_product_icon_html(product_id="", text="", size=58):
    icon_map = cached_icon_map()
    record = icon_map.get(clean_cell(product_id), {})

    icon_file = clean_cell(record.get("icon_file", ""))

    if icon_file:
        # Dosya yolu CSV'de icons/openmoji/xxx.svg veya sadece xxx.svg olabilir.
        candidates = [
            icon_file,
            os.path.join(ICON_DIR, icon_file),
            os.path.join(ICON_DIR, os.path.basename(icon_file)),
        ]

        for path in candidates:
            if os.path.exists(path):
                try:
                    with open(path, "rb") as f:
                        encoded = base64.b64encode(f.read()).decode("utf-8")
                    return f'<img src="data:image/svg+xml;base64,{encoded}" style="width:{size}px;height:{size}px;object-fit:contain;display:block;margin:0 auto 6px auto;" />'
                except Exception:
                    break

    emoji = clean_cell(record.get("emoji", "")) or infer_icon_emoji(text)

    return f'<div style="font-size:{size}px; line-height:1; text-align:center; margin-bottom:6px;">{emoji}</div>'



def get_specs_preview(product_id, max_items=4):
    if specs_df.empty:
        return ""

    subset = specs_df[specs_df["product_id"] == product_id]

    if subset.empty:
        return ""

    items = []
    for _, row in subset.head(max_items).iterrows():
        items.append(f"{row['ozellik_adi']}: {row['ozellik_degeri']}")

    return " • ".join(items)


def get_reference_preview(product_id):
    if reference_df.empty:
        return ""

    subset = reference_df[reference_df["product_id"] == product_id]

    if subset.empty:
        return ""

    first = subset.iloc[0]
    kaynak = clean_cell(first.get("veri_kaynak_adi", ""))
    fiyat = clean_cell(first.get("referans_fiyat", ""))
    para = clean_cell(first.get("para_birimi", "")) or "₺"

    return compact_join([kaynak, f"{fiyat} {para}" if fiyat else ""], sep=" / ")


def source_label(row):
    return compact_join([
        row.get("source_name", ""),
        row.get("source_type", ""),
    ], sep=" • ")


def select_source_from_row(row):
    st.session_state.source_id = clean_cell(row.get("source_id", ""))
    st.session_state.source_type = clean_cell(row.get("source_type", ""))
    st.session_state.source_name = clean_cell(row.get("source_name", ""))
    st.session_state.source_auto_selected = False
    st.session_state.step = "product_tree"
    reset_tree(1)


def select_manual_source(source_type, source_name):
    st.session_state.source_id = "USER_" + normalize_for_search(source_name).replace(" ", "_")[:50]
    st.session_state.source_type = clean_cell(source_type) or "Kullanıcı Girdisi"
    st.session_state.source_name = clean_cell(source_name)
    st.session_state.source_auto_selected = False
    st.session_state.step = "product_tree"
    reset_tree(1)



def build_receipt_item_from_product_row(product_row):
    product_id = clean_cell(product_row.get("product_id", ""))

    return {
        "line_id": "L" + str(len(st.session_state.receipt_items) + 1).zfill(3),
        "product_id": product_id,
        "urun_adi": clean_cell(product_row.get("urun_adi", "")),
        "marka": clean_cell(product_row.get("marka", "")),
        "model": clean_cell(product_row.get("model", "")),
        "varyant": "",
        "birim": clean_cell(product_row.get("birim", "")) or "Adet",
        "title": format_product_title(product_row),
        "path": format_product_subtitle(product_row),
        "sektor": clean_cell(product_row.get("sektor", "")),
        "ana_kategori": clean_cell(product_row.get("ana_kategori", "")),
        "alt_kategori": clean_cell(product_row.get("alt_kategori", "")),
        "urun_turu": clean_cell(product_row.get("urun_turu", "")),
        "fiyat": "",
        "not": "",
    }


def get_last_receipt_lines_for_active_research():
    """
    Aktif fiyat araştırmasındaki son kaydedilen fişin ürün satırlarını getirir.
    Amaç: yeni konum/kaynak için aynı ürün listesini tek butonla tekrar fişe almak.
    Fiyat ve kaynak kopyalanmaz; sadece ürün listesi kopyalanır.
    """
    saved_df = read_saved_price_records()

    if saved_df.empty:
        return pd.DataFrame()

    research_id = clean_cell(st.session_state.get("active_research_id", ""))

    if research_id and "research_id" in saved_df.columns:
        saved_df = saved_df[saved_df["research_id"] == research_id].copy()

    if saved_df.empty:
        return pd.DataFrame()

    saved_df = saved_df[saved_df["receipt_id"] != ""].copy()

    if saved_df.empty:
        return pd.DataFrame()

    latest_receipt_id = (
        saved_df
        .sort_values(["tarih", "saat"], ascending=[False, False])
        .iloc[0]["receipt_id"]
    )

    latest = saved_df[saved_df["receipt_id"] == latest_receipt_id].copy()
    latest = latest.drop_duplicates(subset=["product_id"], keep="first")

    return latest


def import_last_receipt_product_list():
    last_lines = get_last_receipt_lines_for_active_research()

    if last_lines.empty:
        st.warning("Bu araştırmada kopyalanacak önceki fiş bulunamadı.")
        return

    added_count = 0
    skipped_count = 0

    existing_ids = {
        clean_cell(item.get("product_id", ""))
        for item in st.session_state.receipt_items
    }

    for _, line in last_lines.iterrows():
        product_id = clean_cell(line.get("product_id", ""))

        if not product_id or product_id in existing_ids:
            skipped_count += 1
            continue

        matched = products_df[products_df["product_id"] == product_id]

        if not matched.empty:
            product_row = matched.iloc[0]
            item = build_receipt_item_from_product_row(product_row)
        else:
            # Ürün artık master datada bulunamazsa, fiyat kaydındaki temel bilgilerle yine de ekle.
            fallback_row = {
                "product_id": product_id,
                "urun_adi": clean_cell(line.get("urun_adi", "")),
                "marka": clean_cell(line.get("marka", "")),
                "model": clean_cell(line.get("model", "")),
                "birim": clean_cell(line.get("birim", "")) or "Adet",
                "sektor": "",
                "ana_kategori": "",
                "alt_kategori": "",
                "urun_turu": "",
            }
            item = build_receipt_item_from_product_row(fallback_row)

        st.session_state.receipt_items.append(item)
        existing_ids.add(product_id)
        added_count += 1

    # Önceki kaynak kopyalanmasın; yeni lokasyon/kaynak için yeniden önerilsin.
    st.session_state.source_id = ""
    st.session_state.source_type = ""
    st.session_state.source_name = ""
    st.session_state.source_auto_selected = False

    st.success(f"Son fişteki {added_count} ürün listeye eklendi.")

    if skipped_count:
        st.caption(f"{skipped_count} ürün zaten listede olduğu için atlandı.")



def add_to_receipt(product_row):
    product_id = clean_cell(product_row.get("product_id", ""))

    already = [
        item for item in st.session_state.receipt_items
        if item["product_id"] == product_id
    ]

    if already:
        st.toast("Bu ürün fişte zaten var.")
        return

    item = build_receipt_item_from_product_row(product_row)

    st.session_state.receipt_items.append(item)

    if st.session_state.get("source_auto_selected", False):
        st.session_state.source_id = ""
        st.session_state.source_type = ""
        st.session_state.source_name = ""

    st.toast("Fişe eklendi.")


def remove_from_receipt(index):
    if 0 <= index < len(st.session_state.receipt_items):
        st.session_state.receipt_items.pop(index)

    if st.session_state.get("source_auto_selected", False):
        st.session_state.source_id = ""
        st.session_state.source_type = ""
        st.session_state.source_name = ""

    for i, item in enumerate(st.session_state.receipt_items, start=1):
        item["line_id"] = "L" + str(i).zfill(3)


def update_receipt_prices_from_inputs():
    for i, item in enumerate(st.session_state.receipt_items):
        price_key = f"receipt_price_{i}_{item['product_id']}"
        note_key = f"receipt_note_{i}_{item['product_id']}"

        item["fiyat"] = clean_cell(st.session_state.get(price_key, item.get("fiyat", "")))
        item["not"] = clean_cell(st.session_state.get(note_key, item.get("not", "")))


def save_receipt():
    update_receipt_prices_from_inputs()

    if not st.session_state.get("research_active", False) or not st.session_state.get("active_research_id", ""):
        st.error("Fiş kaydetmeden önce Fiyat Araştırması Başlat.")
        return

    if not st.session_state.location_confirmed:
        st.error("Bu yeni fiş için konumu güncellemen gerekiyor.")
        return

    if not st.session_state.source_name:
        st.error("Kaydetmeden önce önerilen fiş kaynağını onayla, değiştir ya da elle yaz.")
        return

    if not st.session_state.receipt_items:
        st.error("Fişte ürün yok.")
        return

    valid_items = []
    invalid_items = []

    for item in st.session_state.receipt_items:
        price = parse_price(item.get("fiyat", ""))
        if price is None:
            invalid_items.append(item)
        else:
            item_copy = item.copy()
            item_copy["fiyat"] = price
            valid_items.append(item_copy)

    if invalid_items:
        st.error("Fiyatı boş veya hatalı ürün var. Kaydetmeden önce tüm fiyatları gir.")
        return

    receipt_id = "R" + datetime.now().strftime("%Y%m%d%H%M%S") + "_" + uuid.uuid4().hex[:6]
    tarih, saat = get_today_strings()

    header_row = {
        "receipt_id": receipt_id,
        "research_id": st.session_state.active_research_id,
        "tarih": tarih,
        "saat": saat,
        "source_id": st.session_state.source_id,
        "source_type": st.session_state.source_type,
        "source_name": st.session_state.source_name,
        "konum_lat": st.session_state.location_lat,
        "konum_lon": st.session_state.location_lon,
        "konum_dogrulandi": st.session_state.location_confirmed,
        "toplam_kalem": len(valid_items),
        "not": st.session_state.receipt_note,
    }

    line_rows = []

    for item in valid_items:
        line_rows.append({
            "receipt_id": receipt_id,
            "research_id": st.session_state.active_research_id,
            "line_id": item["line_id"],
            "tarih": tarih,
            "saat": saat,
            "source_id": st.session_state.source_id,
            "source_type": st.session_state.source_type,
            "source_name": st.session_state.source_name,
            "product_id": item["product_id"],
            "urun_adi": item["urun_adi"],
            "marka": item["marka"],
            "model": item["model"],
            "varyant": item["varyant"],
            "birim": item["birim"],
            "fiyat": item["fiyat"],
            "konum_lat": st.session_state.location_lat,
            "konum_lon": st.session_state.location_lon,
            "not": item.get("not", ""),
        })

    append_csv(RECEIPT_HEADER_FILE, [header_row], RECEIPT_HEADER_COLUMNS)
    append_csv(PRICE_RECORDS_FILE, line_rows, PRICE_RECORD_COLUMNS)

    st.session_state.last_save_status = f"Fiş kaydedildi: {receipt_id}"
    st.session_state.compare_receipt_id = receipt_id
    st.session_state.compare_research_id = st.session_state.active_research_id
    st.session_state.receipt_items = []
    st.session_state.clear_receipt_inputs_next_run = True

    # Yeni fiş yeni kaynak ve yeni konum doğrulaması ister.
    st.session_state.source_id = ""
    st.session_state.source_type = ""
    st.session_state.source_name = ""
    st.session_state.source_auto_selected = False
    st.session_state.location_confirmed = False
    st.session_state.needs_location_update = True

    st.success(st.session_state.last_save_status)


# =========================================================
# 5. ARAMA
# =========================================================

def search_products(query, limit=40):
    query_norm = normalize_for_search(query)

    if len(query_norm) < 3 or products_df.empty:
        return pd.DataFrame(columns=products_df.columns)

    tokens = query_norm.split()

    result = products_df[
        products_df["search_text"].apply(
            lambda text: all(token in text for token in tokens)
        )
    ].copy()

    if result.empty and len(tokens) > 1:
        result = products_df[
            products_df["search_text"].apply(
                lambda text: any(token in text for token in tokens)
            )
        ].copy()

    if result.empty:
        return result

    def score_row(row):
        main_text = normalize_for_search(compact_join([
            row.get("marka", ""),
            row.get("model", ""),
            row.get("urun_adi", ""),
        ]))

        path_text = normalize_for_search(row.get("ui_path", ""))

        score = 0

        if query_norm in main_text:
            score += 100

        if query_norm in path_text:
            score += 50

        for token in tokens:
            if token in main_text:
                score += 20
            if token in path_text:
                score += 8

        return score

    result["search_score"] = result.apply(score_row, axis=1)
    result = result.sort_values("search_score", ascending=False).head(limit)

    return result


# =========================================================
# 6. CSS
# =========================================================

st.markdown("""
<style>
.main-card {
    border: 1px solid #e2e8f0;
    border-radius: 18px;
    padding: 14px;
    background: #ffffff;
    margin-bottom: 12px;
}

.small-muted {
    color: #64748b;
    font-size: 12px;
}

.product-title {
    color: #0f172a;
    font-size: 15px;
    font-weight: 800;
}

.product-path {
    color: #64748b;
    font-size: 12px;
}

.receipt-box {
    border: 2px solid #0f172a;
    border-radius: 18px;
    padding: 14px;
    background: #f8fafc;
    margin-bottom: 16px;
}

.receipt-item {
    border-bottom: 1px solid #e2e8f0;
    padding: 8px 0;
}

.stButton>button {
    min-height: 48px;
    border-radius: 12px;
    font-weight: 700;
}

div[data-testid="stTextInput"] input {
    min-height: 42px;
}
.fixed-bottom-nav {
    position: fixed;
    bottom: 0;
    left: 0;
    width: 100%;
    background: #ffffff;
    border-top: 1px solid #cbd5e1;
    padding: 10px 12px;
    z-index: 9999;
    box-shadow: 0 -4px 14px rgba(15, 23, 42, 0.12);
}
.bottom-spacer {
    height: 86px;
}
</style>
""", unsafe_allow_html=True)


# =========================================================
# 7. SESSION STATE
# =========================================================

def init_state():
    defaults = {
        "step": "location",
        "location_lat": "",
        "location_lon": "",
        "location_confirmed": False,

        "source_id": "",
        "source_type": "",
        "source_name": "",
        "source_auto_selected": False,

        "receipt_items": [],
        "receipt_note": "",
        "last_save_status": "",
        "compare_receipt_id": "",

        "research_active": False,
        "active_research_id": "",
        "active_research_mode": "",
        "compare_research_id": "",
        "research_start_mode": "Bugün alacağım",
        "research_history_index": 0,
        "needs_location_update": False,
        "shopping_checked": {},
        "current_shopping_id": "",

        "product_list_limit": 12,
        "search_query": "",
        "search_limit": 8,
        "clear_search_query_next_run": False,
        "clear_receipt_inputs_next_run": False,
        "source_group_filter": "Tümü",
        "price_entry_index": None,
        "price_entry_value": "",
    }

    for i in range(1, 6):
        defaults[f"level_{i}"] = ""

    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


init_state()
load_open_research_into_state()


# =========================================================
# 8. ÜST BİLGİ
# =========================================================

st.title("🧾 FiyatCep")
st.caption("Data paketi: v9 + araştırma oturumu v1")

if st.session_state.get("research_active", False):
    st.success(f"Açık fiyat araştırması: {st.session_state.active_research_mode}")
else:
    st.caption("Açık fiyat araştırması yok.")

if st.session_state.source_name:
    st.caption(
        f"Fiş kaynağı: {st.session_state.source_name}"
        + (f" / {st.session_state.source_type}" if st.session_state.source_type else "")
    )
else:
    st.caption("Önce ürünleri seç. Fişi kaydetmeden önce fiyat kaynağını seçeceksin.")

if st.session_state.last_save_status:
    st.success(st.session_state.last_save_status)


# =========================================================
# 9. FİŞ PANELİ
# =========================================================

def apply_auto_source_if_needed():
    if not st.session_state.receipt_items:
        return

    if st.session_state.source_name and not st.session_state.get("source_auto_selected", False):
        return

    suggestion = get_best_source_suggestion()

    if suggestion is None:
        return

    suggested_id = clean_cell(suggestion.get("source_id", ""))

    if st.session_state.source_id == suggested_id and st.session_state.source_name:
        return

    st.session_state.source_id = suggested_id
    st.session_state.source_type = clean_cell(suggestion.get("source_type", ""))
    st.session_state.source_name = clean_cell(suggestion.get("source_name", ""))
    st.session_state.source_auto_selected = True



def open_price_entry(index):
    if index < 0 or index >= len(st.session_state.receipt_items):
        return

    item = st.session_state.receipt_items[index]
    st.session_state.price_entry_index = index
    st.session_state.price_entry_value = clean_cell(item.get("fiyat", ""))
    st.session_state.step = "price_entry"


def render_price_entry_screen():
    index = st.session_state.get("price_entry_index", None)

    if index is None or index < 0 or index >= len(st.session_state.receipt_items):
        st.warning("Fiyat girilecek ürün bulunamadı.")
        if st.button("⬅️ Fişe Dön", use_container_width=True):
            st.session_state.step = "product_tree"
            st.rerun()
        return

    item = st.session_state.receipt_items[index]
    title = clean_cell(item.get("title", ""))

    st.subheader("💰 Fiyat Gir")
    st.markdown(f"### {title}")

    value = clean_cell(st.session_state.get("price_entry_value", ""))
    display_value = value if value else "0"

    st.markdown(
        f"""
        <div style="
            border:2px solid #0f172a;
            border-radius:18px;
            padding:18px;
            text-align:right;
            font-size:42px;
            font-weight:900;
            margin:12px 0;
            background:#f8fafc;
        ">
            {display_value} ₺
        </div>
        """,
        unsafe_allow_html=True
    )

    def press(val):
        current = clean_cell(st.session_state.get("price_entry_value", ""))

        if val == "C":
            current = ""
        elif val == "⌫":
            current = current[:-1]
        elif val == ",":
            if "," not in current and "." not in current:
                current = current + ","
        else:
            current = current + val

        st.session_state.price_entry_value = current

    keypad = [
        ["1", "2", "3"],
        ["4", "5", "6"],
        ["7", "8", "9"],
        [",", "0", "⌫"],
    ]

    for r, row in enumerate(keypad):
        cols = st.columns(3)
        for c, val in enumerate(row):
            if cols[c].button(val, key=f"keypad_{r}_{c}_{val}", use_container_width=True):
                press(val)
                st.rerun()

    c1, c2, c3 = st.columns(3)

    if c1.button("Temizle", use_container_width=True):
        press("C")
        st.rerun()

    if c2.button("İptal", use_container_width=True):
        st.session_state.step = "product_tree"
        st.rerun()

    if c3.button("Kaydet", use_container_width=True, type="primary"):
        price = parse_price(st.session_state.price_entry_value)

        if price is None:
            st.error("Geçerli bir fiyat gir.")
            return

        st.session_state.receipt_items[index]["fiyat"] = str(price).replace(".", ",")
        st.session_state.price_entry_index = None
        st.session_state.price_entry_value = ""
        st.session_state.step = "product_tree"
        st.rerun()



def render_receipt_panel():
    st.markdown('<div class="receipt-box">', unsafe_allow_html=True)

    st.subheader("Fiş / Adisyon")

    if st.session_state.get("needs_location_update", False) or not st.session_state.location_confirmed:
        st.warning("Yeni fiş için konum güncellemesi gerekli.")
        if st.button("📍 Konumu Güncelle", use_container_width=True, key="receipt_update_location"):
            st.session_state.step = "location"
            st.rerun()

    # Streamlit kuralı:
    # Bir widget aynı çalıştırmada oluşturulduktan sonra onun session_state key'i değiştirilemez.
    # Bu yüzden fiş notu ve fiyat input temizliği, widgetlar oluşturulmadan önce yapılır.
    if st.session_state.get("clear_receipt_inputs_next_run", False):
        st.session_state.receipt_note = ""

        for key in list(st.session_state.keys()):
            if key.startswith("receipt_price_") or key.startswith("receipt_note_"):
                del st.session_state[key]

        st.session_state.clear_receipt_inputs_next_run = False

    apply_auto_source_if_needed()

    if not st.session_state.source_name:
        st.caption("Kaynak henüz seçilmedi. Önce ürün ekle; sonra kaynak önerisi otomatik gelecek.")
    else:
        csrc1, csrc2 = st.columns([3, 1])
        auto_note = "Otomatik öneri" if st.session_state.get("source_auto_selected", False) else "Seçili kaynak"
        csrc1.markdown(
            f"**{st.session_state.source_name}**  \\n"
            f"<small>{st.session_state.source_type} • {auto_note}</small>",
            unsafe_allow_html=True
        )
        if csrc2.button("Değiştir", key="change_source_from_receipt"):
            st.session_state.step = "source_smart"
            st.rerun()

    if not st.session_state.receipt_items:
        st.info("Fişe henüz ürün eklenmedi.")

        last_lines = get_last_receipt_lines_for_active_research()

        if not last_lines.empty:
            st.caption("Yeni konum/kaynak için aynı ürün listesini tekrar gireceksen:")
            if st.button("📋 Son fişteki ürün listesini ekle", use_container_width=True, key="import_last_receipt_items"):
                import_last_receipt_product_list()
                st.rerun()

    else:
        update_receipt_prices_from_inputs()

        total = 0.0
        all_valid = True

        rows = list(enumerate(st.session_state.receipt_items))
        products_per_row = 4

        for start_idx in range(0, len(rows), products_per_row):
            chunk = rows[start_idx:start_idx + products_per_row]
            cols = st.columns(products_per_row)

            for col_idx, (i, item) in enumerate(chunk):
                with cols[col_idx]:
                    price_key = f"receipt_price_{i}_{item['product_id']}"
                    current_price = clean_cell(item.get("fiyat", ""))

                    if price_key in st.session_state:
                        current_price = clean_cell(st.session_state.get(price_key, current_price))
                        item["fiyat"] = current_price

                    parsed = parse_price(current_price)

                    if parsed is None:
                        all_valid = False
                        price_text = "Fiyat gir"
                        price_color = "#dc2626"
                    else:
                        total += parsed
                        price_text = f"{format_price(str(parsed))} ₺"
                        price_color = "#0f172a"

                    icon_html = get_product_icon_html(item["product_id"], f"{item['title']} {item['path']}", size=48)

                    st.markdown(
                        f"""
                        <div style="
                            border:1px solid #cbd5e1;
                            border-radius:14px;
                            padding:8px;
                            min-height:178px;
                            background:#ffffff;
                            margin-bottom:6px;
                        ">
                            {icon_html}
                            <div style="font-weight:900; font-size:13px; line-height:1.18; color:#0f172a;">{i + 1}. {item['title']}</div>
                            <div style="font-size:10px; color:#64748b; margin-top:5px;">{item['birim']} • {item['path']}</div>
                            <div style="font-size:18px; color:{price_color}; font-weight:900; margin-top:8px;">{price_text}</div>
                        </div>
                        """,
                        unsafe_allow_html=True
                    )

                    if st.button(
                        "💰 Fiyat Gir",
                        key=safe_key("open_price_entry", item["product_id"], i),
                        use_container_width=True
                    ):
                        open_price_entry(i)
                        st.rerun()

                    if st.button(
                        "Sil",
                        key=safe_key("remove_receipt", item["product_id"], i),
                        use_container_width=True
                    ):
                        remove_from_receipt(i)
                        st.rerun()

        st.markdown(f"### Toplam: {format_price(str(total))} ₺")

        st.text_input(
            "Fiş notu",
            key="receipt_note",
            placeholder="Opsiyonel fiş notu",
        )

        s1, s2, s3 = st.columns(3)

        if s1.button("✅ FİŞİ KAYDET", use_container_width=True, type="primary"):
            save_receipt()
            st.rerun()

        if s2.button("📊 En Ucuz / Rota", use_container_width=True):
            st.session_state.step = "compare_prices"
            st.rerun()

        if s3.button("🧹 Temizle", use_container_width=True):
            st.session_state.receipt_items = []
            st.session_state.clear_receipt_inputs_next_run = True
            st.rerun()

        if not all_valid:
            st.caption("Kaydetmek için tüm ürünlerin fiyatı geçerli olmalı.")

    st.markdown('</div>', unsafe_allow_html=True)


# =========================================================
# 10. EKRANLAR
# =========================================================

def render_location_screen():
    st.subheader("Konum")

    if HAS_MAP:
        m = folium.Map(location=[41.0082, 28.9784], zoom_start=12)
        st_folium(m, height=240, width=700)
    else:
        st.info("Harita paketi kurulu değil. Konum alanı test modunda çalışıyor.")

    st.caption("Bu ekranda şimdilik konum onayı alınıyor. Gerçek GPS entegrasyonu ayrıca eklenebilir.")

    button_label = "Konumu Güncelle" if st.session_state.get("needs_location_update", False) else "Konumu Onayla ve Başla"

    if st.button(button_label, use_container_width=True, type="primary"):
        st.session_state.location_confirmed = True
        st.session_state.needs_location_update = False

        if st.session_state.get("research_active", False):
            st.session_state.step = "product_tree"
        else:
            st.session_state.step = "research_start"

        st.rerun()



def render_research_start_screen():
    st.subheader("Fiyat Araştırması")

    if st.session_state.get("research_active", False):
        st.success(f"Açık araştırma var: {st.session_state.active_research_mode}")

        c1, c2 = st.columns(2)

        if c1.button("▶️ Araştırmaya Devam Et", use_container_width=True, type="primary"):
            st.session_state.step = "product_tree"
            st.rerun()

        if c2.button("🏁 Fiyat Araştırmasını Bitir", use_container_width=True):
            finish_research_session()
            st.rerun()

        return

    st.caption("Fiyat karşılaştırması sadece Başlat ile Bitir arasındaki fişleri değerlendirecek.")

    mode = st.radio(
        "Araştırma modu",
        ["Bugün alacağım", "Geniş fiyat araştırması"],
        key="research_start_mode",
        horizontal=True,
    )

    if st.button("🔍 Fiyat Araştırması Başlat", use_container_width=True, type="primary"):
        start_research_session(mode)
        st.rerun()

    st.markdown("---")

    c_old1, c_old2 = st.columns(2)

    if c_old1.button("📊 Son Araştırmayı Göster", use_container_width=True):
        saved_df = read_saved_price_records()
        research_id = get_compare_research_id(saved_df)
        if research_id:
            st.session_state.compare_research_id = research_id
            st.session_state.step = "compare_prices"
            st.rerun()
        else:
            st.warning("Gösterilecek geçmiş araştırma bulunamadı.")

    if c_old2.button("📋 Yapılacak Alışverişler", use_container_width=True):
        st.session_state.step = "pending_shopping"
        st.rerun()



def render_source_type_screen():
    st.subheader("Fiş kaynağı seç")
    st.caption("Bu seçim ürün ağacını açmak için değil, fişi kaydederken fiyatın nereden alındığını belirtmek içindir.")

    if st.button("⬅️ Ürünlere Dön", use_container_width=True):
        st.session_state.step = "product_tree"
        st.rerun()

    if sources_df.empty:
        st.warning("source_master.csv içinde kaynak yok. Elle kaynak girebilirsin.")
    else:
        source_types = [
            clean_cell(x)
            for x in sources_df["source_type"].dropna().unique()
            if clean_cell(x)
        ]

        source_type_order = {
            "Gıda Marketi": 1,
            "Pazar": 2,
            "Esnaf": 3,
            "Elektronik Marketi": 4,
            "Elektronik Market": 4,
            "Online Mağaza": 5,
            "Marka Mağazası": 6,
        }

        source_types = sorted(
            source_types,
            key=lambda x: (source_type_order.get(x, 99), normalize_for_search(x))
        )

        st.caption("Kaynak türleri source_master.csv dosyasından okunuyor.")

        cols = st.columns(2)

        for i, source_type in enumerate(source_types):
            count = len(sources_df[sources_df["source_type"] == source_type])

            if cols[i % 2].button(
                f"{source_type} ({count})",
                key=safe_key("source_type", source_type, i),
                use_container_width=True,
            ):
                st.session_state.selected_source_type = source_type
                st.session_state.source_group_filter = "Tümü"
                st.session_state.step = "source_name"
                st.rerun()

    with st.expander("Kaynağı elle yaz"):
        manual_type = st.text_input("Kaynak türü", placeholder="Örn: Yerel mağaza, bayi, pazar...")
        manual_name = st.text_input("Kaynak adı", placeholder="Örn: Kadıköy Elektronikçi...")

        if st.button("Elle Kaynağı Kullan", use_container_width=True):
            if clean_cell(manual_name):
                select_manual_source(manual_type, manual_name)
                st.rerun()
            else:
                st.error("Kaynak adı boş olamaz.")



def get_receipt_context_for_sources():
    """
    Fişe eklenen ürünlerden kaynak seçiminde kullanılacak bağlamı çıkarır.
    Amaç: Kaynak seçerken tüm marka mağazalarını göstermek yerine,
    fişteki ürünlerin sektör/kategori/markasına uygun kaynakları öne getirmek.
    """
    sectors = set()
    categories = set()
    alt_categories = set()
    product_types = set()
    brands = set()

    for item in st.session_state.receipt_items:
        for key, target_set in [
            ("sektor", sectors),
            ("ana_kategori", categories),
            ("alt_kategori", alt_categories),
            ("urun_turu", product_types),
            ("marka", brands),
        ]:
            value = clean_cell(item.get(key, ""))
            if value:
                target_set.add(value)

    return {
        "sectors": sectors,
        "categories": categories,
        "alt_categories": alt_categories,
        "product_types": product_types,
        "brands": brands,
    }


def split_scope(value):
    return [
        clean_cell(x)
        for x in str(value).split("|")
        if clean_cell(x)
    ]


def source_matches_receipt(row, context):
    if not st.session_state.receipt_items:
        return True

    source_type = clean_cell(row.get("source_type", ""))
    related_brand = clean_cell(row.get("related_brand", ""))
    sector_scope = clean_cell(row.get("sector_scope", ""))
    category_scope_values = split_scope(row.get("category_scope", ""))

    sectors = context["sectors"]
    categories = context["categories"]
    alt_categories = context["alt_categories"]
    product_types = context["product_types"]
    brands = context["brands"]

    if source_type == "Marka Mağazası":
        return related_brand in brands if related_brand else False

    if source_type in ["Elektronik Marketi", "Elektronik Market"]:
        return "Elektronik" in sectors

    if source_type == "Gıda Marketi":
        # Gıda marketleri temizlik ürünleri de sattığı için
        # Temizlik araştırmalarında Kim/Bim/Şok/A-101/Migros gibi kaynaklar da gelmeli.
        return ("Gıda" in sectors) or ("Temizlik" in sectors)

    if source_type in ["Pazar", "Esnaf"]:
        return "Gıda" in sectors

    if source_type == "Online Mağaza":
        return True

    if sector_scope:
        if sector_scope not in sectors:
            return False
    else:
        return False

    if category_scope_values:
        product_scope_values = categories | alt_categories | product_types
        return bool(set(category_scope_values) & product_scope_values)

    return True


def source_relevance_score(row, context):
    score = 0

    if not st.session_state.receipt_items:
        return score

    source_type = clean_cell(row.get("source_type", ""))
    related_brand = clean_cell(row.get("related_brand", ""))
    sector_scope = clean_cell(row.get("sector_scope", ""))
    category_scope_values = split_scope(row.get("category_scope", ""))

    if related_brand and related_brand in context["brands"]:
        score += 100

    if source_type == "Marka Mağazası" and related_brand in context["brands"]:
        score += 50

    if source_type == "Gıda Marketi" and "Temizlik" in context["sectors"]:
        score += 45

    if source_type == "Online Mağaza":
        score += 20

    if sector_scope and sector_scope in context["sectors"]:
        score += 30

    product_scope_values = context["categories"] | context["alt_categories"] | context["product_types"]

    if category_scope_values:
        score += 15 * len(set(category_scope_values) & product_scope_values)

    product_count = pd.to_numeric(row.get("product_count", "0"), errors="coerce")
    if pd.isna(product_count):
        product_count = 0

    score += min(float(product_count), 1000) / 1000

    return score



def get_smart_source_candidates():
    """
    Fişteki ürünlere göre tüm kaynak türleri arasından uygun kaynakları getirir.
    Örnek:
    - Apple ürün varsa Apple Marka Mağazası
    - Elektronik ürün varsa Elektronik Marketi
    - Gıda ürün varsa Gıda Marketi
    - Online mağazalar genel alternatif olarak görünür
    """
    context = get_receipt_context_for_sources()

    if sources_df.empty:
        return pd.DataFrame(columns=sources_df.columns)

    candidates = sources_df.copy()

    if st.session_state.receipt_items:
        candidates = candidates[
            candidates.apply(lambda row: source_matches_receipt(row, context), axis=1)
        ].copy()

    if not candidates.empty:
        candidates["_score"] = candidates.apply(lambda row: source_relevance_score(row, context), axis=1)
        candidates["_pc"] = pd.to_numeric(candidates.get("product_count", "0"), errors="coerce").fillna(0)

        type_order = {
            "Marka Mağazası": 1,
            "Elektronik Marketi": 2,
            "Elektronik Market": 2,
            "Gıda Marketi": 2,
            "Online Mağaza": 3,
            "Pazar": 4,
            "Esnaf": 5,
        }

        candidates["_type_order"] = candidates["source_type"].map(type_order).fillna(99)
        candidates = candidates.sort_values(
            ["_score", "_type_order", "_pc", "source_name"],
            ascending=[False, True, False, True]
        )
        candidates = candidates.drop(columns=["_score", "_pc", "_type_order"])

    return candidates


def get_best_source_suggestion():
    candidates = get_smart_source_candidates()

    if candidates.empty:
        return None

    return candidates.iloc[0]


def confirm_source_row(row):
    st.session_state.source_id = clean_cell(row.get("source_id", ""))
    st.session_state.source_type = clean_cell(row.get("source_type", ""))
    st.session_state.source_name = clean_cell(row.get("source_name", ""))
    st.session_state.source_auto_selected = False
    st.session_state.step = "product_tree"


def render_smart_source_screen():
    st.subheader("Fiş kaynağı")

    if st.button("⬅️ Ürünlere Dön", use_container_width=True):
        st.session_state.step = "product_tree"
        st.rerun()

    candidates = get_smart_source_candidates()

    if candidates.empty:
        st.warning("Fişteki ürünlere göre kaynak önerisi bulunamadı. Kaynağı elle yazabilirsin.")
    else:
        if st.session_state.receipt_items:
            st.caption("Fişteki ürünlerin marka/kategorisine göre önerilen kaynaklar.")
        else:
            st.caption("Fişte ürün yoksa genel kaynak listesi gösterilir.")

        query = st.text_input("Kaynak ara", placeholder="Örn: Apple, MediaMarkt, Trendyol...")

        if clean_cell(query):
            q = normalize_for_search(query)
            candidates = candidates[
                candidates["source_name"].apply(lambda x: q in normalize_for_search(x))
                | candidates["source_type"].apply(lambda x: q in normalize_for_search(x))
            ]

        st.caption(f"{len(candidates)} kaynak")

        for i, (_, row) in enumerate(candidates.iterrows()):
            c1, c2 = st.columns([3, 1])

            c1.markdown(f"**{row['source_name']}**")
            c1.caption(compact_join([
                row.get("source_type", ""),
                row.get("sector_scope", ""),
                row.get("category_scope", ""),
                f"{row.get('product_count', '')} ürün" if clean_cell(row.get("product_count", "")) else "",
            ], sep=" • "))

            if c2.button("Seç", key=safe_key("smart_source_select", row["source_id"], i), use_container_width=True):
                confirm_source_row(row)
                st.rerun()

            st.divider()

    with st.expander("Kaynağı elle yaz"):
        manual_type = st.text_input(
            "Kaynak türü",
            key="manual_source_type_smart",
            placeholder="Örn: Yerel mağaza, bayi, pazar..."
        )
        manual_name = st.text_input(
            "Kaynak adı",
            key="manual_source_name_smart",
            placeholder="Örn: Kadıköy Elektronikçi..."
        )

        if st.button("Elle Kaynağı Kullan", use_container_width=True, key="manual_source_use_smart"):
            if clean_cell(manual_name):
                select_manual_source(manual_type, manual_name)
                st.rerun()
            else:
                st.error("Kaynak adı boş olamaz.")

    # Eski kaynak türü menüsü bilinçli olarak gizlendi.
    # Kaynak değiştirme artık fişteki ürünlere göre daraltılmış liste üzerinden yapılır.


def render_source_name_screen():
    selected_type = clean_cell(st.session_state.get("selected_source_type", ""))

    st.subheader(selected_type or "Kaynak")

    filtered = sources_df[sources_df["source_type"] == selected_type].copy()

    context = get_receipt_context_for_sources()

    if filtered.empty:
        st.warning("Bu kaynak türü altında kayıt yok.")
    else:
        if st.session_state.receipt_items:
            before_count = len(filtered)
            filtered = filtered[
                filtered.apply(lambda row: source_matches_receipt(row, context), axis=1)
            ].copy()

            if not filtered.empty:
                st.caption(
                    f"Fişteki ürünlere göre uygun kaynaklar gösteriliyor. "
                    f"{len(filtered)} / {before_count}"
                )
            else:
                st.warning("Fişteki ürünlere uygun kaynak bulunamadı. İstersen kaynağı elle yazabilirsin.")
                filtered = sources_df[sources_df["source_type"] == selected_type].copy()
                st.caption("Uygun kaynak bulunamadığı için bu türdeki tüm kaynaklar geçici olarak gösteriliyor.")
        else:
            st.caption("Fişte ürün yoksa kaynaklar genel liste olarak gösterilir.")

        query = st.text_input("Kaynak ara", placeholder="Marka / kaynak adı yaz...")

        if clean_cell(query):
            q = normalize_for_search(query)
            filtered = filtered[
                filtered["source_name"].apply(lambda x: q in normalize_for_search(x))
            ]

        if not filtered.empty:
            filtered["_score"] = filtered.apply(lambda row: source_relevance_score(row, context), axis=1)
            filtered["_pc"] = pd.to_numeric(filtered.get("product_count", "0"), errors="coerce").fillna(0)
            filtered = filtered.sort_values(["_score", "_pc", "source_name"], ascending=[False, False, True])
            filtered = filtered.drop(columns=["_score", "_pc"])

        st.caption(f"{len(filtered)} kaynak")

        for i, (_, row) in enumerate(filtered.iterrows()):
            c1, c2 = st.columns([3, 1])

            c1.markdown(f"**{row['source_name']}**")
            c1.caption(compact_join([
                row.get("source_type", ""),
                row.get("sector_scope", ""),
                row.get("category_scope", ""),
                f"{row.get('product_count', '')} ürün" if clean_cell(row.get("product_count", "")) else "",
            ], sep=" • "))

            if c2.button("Seç", key=safe_key("select_source", row["source_id"], i), use_container_width=True):
                select_source_from_row(row)
                st.rerun()

            st.divider()

    with st.expander("Kaynağı elle yaz"):
        manual_type = st.text_input(
            "Kaynak türü",
            value=selected_type,
            key="manual_source_type_from_name",
            placeholder="Örn: Yerel mağaza, bayi, pazar..."
        )
        manual_name = st.text_input(
            "Kaynak adı",
            key="manual_source_name_from_name",
            placeholder="Örn: Kadıköy Elektronikçi..."
        )

        if st.button("Elle Kaynağı Kullan", use_container_width=True, key="manual_source_use_from_name"):
            if clean_cell(manual_name):
                select_manual_source(manual_type, manual_name)
                st.rerun()
            else:
                st.error("Kaynak adı boş olamaz.")

    cback1, cback2 = st.columns(2)

    if cback1.button("⬅️ Kaynak Türüne Dön", use_container_width=True):
        st.session_state.step = "source_type"
        st.rerun()

    if cback2.button("Ürünlere Dön", use_container_width=True):
        st.session_state.step = "product_tree"
        st.rerun()



def render_tree_breadcrumb():
    selected_parts = []

    for i in range(1, 6):
        value = clean_cell(st.session_state.get(f"level_{i}", ""))
        if value:
            selected_parts.append(value)

    if selected_parts:
        st.caption(" > ".join(selected_parts))


def render_product_tree_screen():
    if not st.session_state.get("research_active", False):
        st.warning("Ürün eklemek için önce Fiyat Araştırması Başlat.")
        st.session_state.step = "research_start"
        st.rerun()

    st.subheader("Ürün seç")
    render_tree_breadcrumb()

    if any(clean_cell(st.session_state.get(f"level_{i}", "")) for i in range(1, 6)):
        n1, n2 = st.columns(2)

        if n1.button("⬅️ Bir üst kategoriye dön", use_container_width=True):
            go_up_one_level()
            st.rerun()

        if n2.button("🏠 Başa dön", use_container_width=True):
            reset_tree(1)
            st.rerun()

    level_no, level_col, options = get_next_level_options()
    filtered_products = get_filtered_products()

    # İlk görünen alan her zaman ürün ağacı / ana kategoriler olsun.
    if level_col and options:
        if level_no == 1:
            st.markdown("#### Ana Kategoriler")
        else:
            st.markdown("#### Seçimle ilerle")

        cols_count = 2 if len(options) < 8 else 3
        cols = st.columns(cols_count)

        for i, option in enumerate(options):
            count = len(filtered_products[filtered_products[level_col] == option])
            label = f"{option} ({count})"

            if cols[i % cols_count].button(
                label,
                key=safe_key(f"level_{level_no}", option, i),
                use_container_width=True,
            ):
                st.session_state[f"level_{level_no}"] = option
                reset_tree(level_no + 1)
                st.rerun()

    # Seçim yeterince daraldıysa veya tüm seviyeler seçildiyse ürünleri göster.
    product_count = len(filtered_products)

    show_products = (
        product_count <= 60 or
        all(clean_cell(st.session_state.get(f"level_{i}", "")) for i in range(1, 6)) or
        (level_col is None)
    )

    if show_products:
        st.markdown("#### Ürünler")
        render_product_list(filtered_products)
    else:
        st.info(f"{product_count} ürün var. Listeyi açmak yerine yukarıdaki seçimlerle daralt.")

    st.markdown("---")

    with st.expander("🔎 Bulamazsan ara", expanded=False):
        render_quick_search()

    st.markdown("---")
    render_receipt_panel()


def render_product_list(df):
    if df.empty:
        st.warning("Bu seçimde ürün yok.")
        return

    df = df.copy()
    df["_display_order"] = df.apply(product_order_score, axis=1)
    df["_name_order"] = df["urun_adi"].apply(normalize_for_search)
    df = df.sort_values(["_display_order", "_name_order"])

    limit = int(st.session_state.product_list_limit)
    visible = df.head(limit)

    st.caption(f"Gösterilen: {len(visible)} / {len(df)}")

    rows = list(visible.iterrows())
    products_per_row = 4

    for start_idx in range(0, len(rows), products_per_row):
        chunk = rows[start_idx:start_idx + products_per_row]
        cols = st.columns(products_per_row)

        for col_idx, (_, row) in enumerate(chunk):
            with cols[col_idx]:
                product_id = row["product_id"]
                title = format_product_title(row)
                subtitle = format_product_subtitle(row)
                specs = get_specs_preview(product_id, max_items=2)

                icon_html = get_product_icon_html(product_id, f"{title} {subtitle}", size=54)

                st.markdown(
                    f"""
                    <div style="
                        border:1px solid #cbd5e1;
                        border-radius:14px;
                        padding:9px;
                        min-height:188px;
                        background:#ffffff;
                        margin-bottom:6px;
                    ">
                        {icon_html}
                        <div style="font-weight:900; font-size:14px; line-height:1.18; color:#0f172a;">{title}</div>
                        <div style="font-size:10px; color:#64748b; margin-top:6px;">{subtitle}</div>
                        <div style="font-size:10px; color:#64748b; margin-top:4px;">{specs}</div>
                    </div>
                    """,
                    unsafe_allow_html=True
                )

                if st.button(
                    "➕ Ekle",
                    key=safe_key("add_product_card", product_id, start_idx + col_idx),
                    use_container_width=True
                ):
                    add_to_receipt(row)
                    st.rerun()

    if len(df) > limit:
        if st.button("➕ Daha fazla ürün göster", use_container_width=True):
            st.session_state.product_list_limit = min(limit + 16, 96)
            st.rerun()


def render_quick_search():
    st.markdown("#### Bulamazsan ara")

    # Streamlit kuralı:
    # Bir widget aynı çalıştırmada oluşturulduktan sonra onun session_state key'i değiştirilemez.
    # Bu yüzden temizleme işlemini bir sonraki rerun'ın başında yapıyoruz.
    if st.session_state.get("clear_search_query_next_run", False):
        st.session_state.search_query = ""
        st.session_state.search_limit = 8
        st.session_state.clear_search_query_next_run = False

    query = st.text_input(
        "Ürün ara",
        key="search_query",
        placeholder="Örn: iPhone 128, Bosch buzdolabı, süt, domates...",
    )

    if not clean_cell(query) or len(normalize_for_search(query)) < 3:
        st.caption("Ana yöntem seçimle ilerlemek. Arama sadece yedek.")
        return

    results = search_products(query, limit=40)

    if results.empty:
        st.warning("Aramada sonuç yok.")
        return

    limit = int(st.session_state.search_limit)
    visible = results.head(limit)

    st.caption(f"Arama sonucu: {len(visible)} / {len(results)}")

    for i, (_, row) in enumerate(visible.iterrows()):
        product_id = row["product_id"]
        title = format_product_title(row)
        subtitle = format_product_subtitle(row)

        c1, c2 = st.columns([4, 1])

        c1.markdown(f"**{title}**")
        c1.caption(subtitle)

        if c2.button("Ekle", key=safe_key("search_add", product_id, i), use_container_width=True):
            add_to_receipt(row)
            st.session_state.clear_search_query_next_run = True
            st.rerun()

        st.divider()

    if len(results) > limit:
        if st.button("Aramada daha fazla göster", use_container_width=True):
            st.session_state.search_limit = min(limit + 8, 40)
            st.rerun()

    if st.button("Aramayı temizle", use_container_width=True):
        st.session_state.clear_search_query_next_run = True
        st.rerun()



# =========================================================
# 11. EN UCUZ / DURAK ÖNERİSİ
# =========================================================


def get_research_history():
    sessions = read_research_sessions()

    if sessions.empty:
        return pd.DataFrame(columns=RESEARCH_SESSION_COLUMNS)

    # Fiş kaydı olan araştırmaları öne alır.
    records = read_saved_price_records()

    if not records.empty and "research_id" in records.columns:
        counts = records[records["research_id"] != ""].groupby("research_id").size().reset_index(name="fis_satiri")
        sessions = sessions.merge(counts, on="research_id", how="left")
    else:
        sessions["fis_satiri"] = 0

    sessions["fis_satiri"] = pd.to_numeric(sessions["fis_satiri"], errors="coerce").fillna(0).astype(int)
    sessions = sessions.sort_values(["baslangic_tarih", "baslangic_saat"], ascending=[False, False]).reset_index(drop=True)

    return sessions


def sync_compare_research_index(history):
    if history.empty:
        st.session_state.research_history_index = 0
        return

    current_id = clean_cell(st.session_state.get("compare_research_id", ""))

    if current_id and current_id in history["research_id"].tolist():
        st.session_state.research_history_index = int(history.index[history["research_id"] == current_id][0])
    else:
        st.session_state.research_history_index = 0
        st.session_state.compare_research_id = history.iloc[0]["research_id"]


def render_research_history_nav():
    history = get_research_history()

    if history.empty:
        return ""

    sync_compare_research_index(history)

    idx = int(st.session_state.get("research_history_index", 0))
    idx = max(0, min(idx, len(history) - 1))
    row = history.iloc[idx]
    st.session_state.compare_research_id = row["research_id"]

    c1, c2, c3 = st.columns([1, 3, 1])

    if c1.button("◀ Önceki", use_container_width=True, disabled=(idx >= len(history) - 1)):
        st.session_state.research_history_index = min(idx + 1, len(history) - 1)
        st.session_state.compare_research_id = history.iloc[st.session_state.research_history_index]["research_id"]
        st.rerun()

    tarih = clean_cell(row.get("baslangic_tarih", ""))
    saat = clean_cell(row.get("baslangic_saat", ""))
    mode = clean_cell(row.get("mode", ""))
    status = clean_cell(row.get("status", ""))
    fis_satiri = clean_cell(row.get("fis_satiri", ""))

    c2.markdown(f"**{tarih} {saat} fiyat araştırması**")
    c2.caption(f"{mode} • {status} • kayıt satırı: {fis_satiri}")

    if c3.button("Sonraki ▶", use_container_width=True, disabled=(idx <= 0)):
        st.session_state.research_history_index = max(idx - 1, 0)
        st.session_state.compare_research_id = history.iloc[st.session_state.research_history_index]["research_id"]
        st.rerun()

    st.caption(f"Araştırma {idx + 1} / {len(history)}")

    return row["research_id"]


def read_shopping_sessions():
    if not os.path.exists(SHOPPING_SESSIONS_FILE):
        return pd.DataFrame(columns=SHOPPING_SESSION_COLUMNS)

    try:
        df = pd.read_csv(SHOPPING_SESSIONS_FILE, dtype=str, encoding="utf-8-sig")
    except UnicodeDecodeError:
        df = pd.read_csv(SHOPPING_SESSIONS_FILE, dtype=str, encoding="cp1254")
    except Exception:
        return pd.DataFrame(columns=SHOPPING_SESSION_COLUMNS)

    df = ensure_columns(df, SHOPPING_SESSION_COLUMNS)

    for col in SHOPPING_SESSION_COLUMNS:
        df[col] = df[col].apply(clean_cell)

    return df[SHOPPING_SESSION_COLUMNS]


def read_shopping_items():
    if not os.path.exists(SHOPPING_ITEMS_FILE):
        return pd.DataFrame(columns=SHOPPING_ITEM_COLUMNS)

    try:
        df = pd.read_csv(SHOPPING_ITEMS_FILE, dtype=str, encoding="utf-8-sig")
    except UnicodeDecodeError:
        df = pd.read_csv(SHOPPING_ITEMS_FILE, dtype=str, encoding="cp1254")
    except Exception:
        return pd.DataFrame(columns=SHOPPING_ITEM_COLUMNS)

    df = ensure_columns(df, SHOPPING_ITEM_COLUMNS)

    for col in SHOPPING_ITEM_COLUMNS:
        df[col] = df[col].apply(clean_cell)

    return df[SHOPPING_ITEM_COLUMNS]


def write_shopping_sessions(df):
    df = ensure_columns(df, SHOPPING_SESSION_COLUMNS)[SHOPPING_SESSION_COLUMNS]
    df.to_csv(SHOPPING_SESSIONS_FILE, index=False, encoding="utf-8-sig")


def write_shopping_items(df):
    df = ensure_columns(df, SHOPPING_ITEM_COLUMNS)[SHOPPING_ITEM_COLUMNS]
    df.to_csv(SHOPPING_ITEMS_FILE, index=False, encoding="utf-8-sig")


def build_shopping_rows_from_route(cheapest_df, research_id, shopping_id, status="yapılacak"):
    tarih, saat = get_today_strings()

    header = {
        "shopping_id": shopping_id,
        "research_id": research_id,
        "status": status,
        "tarih": tarih,
        "saat": saat,
        "toplam": round(float(cheapest_df["en_ucuz_fiyat"].sum()), 2),
        "tasarruf": round(float(cheapest_df["tasarruf"].sum()), 2),
        "tamamlanan_urun": 0,
        "toplam_urun": len(cheapest_df),
        "not": "",
    }

    items = []

    for _, row in cheapest_df.iterrows():
        items.append({
            "shopping_id": shopping_id,
            "research_id": research_id,
            "product_id": clean_cell(row.get("product_id", "")),
            "urun": row.get("urun", ""),
            "source_name": row.get("source_name", ""),
            "source_type": row.get("source_type", ""),
            "fiyat": row.get("en_ucuz_fiyat", ""),
            "tasarruf": row.get("tasarruf", ""),
            "durum": "bekliyor",
            "tarih": tarih,
            "saat": saat,
        })

    return header, items


def get_or_create_shopping_plan(cheapest_df, research_id):
    """
    Alışverişe Başla denince planı ayrı kaydeder.
    Kullanıcı alışveriş yapmasa bile 'yapılacak' olarak kalır.
    Yeni fiyat araştırmasına karışmaz.
    """
    if cheapest_df.empty or not research_id:
        return ""

    sessions = read_shopping_sessions()
    items = read_shopping_items()

    pending = sessions[
        (sessions["research_id"] == research_id) &
        (sessions["status"].isin(["yapılacak", "devam ediyor"]))
    ].copy()

    if not pending.empty:
        shopping_id = pending.sort_values(["tarih", "saat"], ascending=[False, False]).iloc[0]["shopping_id"]
        return shopping_id

    shopping_id = "PLAN_" + datetime.now().strftime("%Y%m%d%H%M%S") + "_" + uuid.uuid4().hex[:5]
    header, item_rows = build_shopping_rows_from_route(cheapest_df, research_id, shopping_id, status="yapılacak")

    sessions = pd.concat([sessions, pd.DataFrame([header])], ignore_index=True)
    items = pd.concat([items, pd.DataFrame(item_rows)], ignore_index=True)

    write_shopping_sessions(sessions)
    write_shopping_items(items)

    return shopping_id


def load_shopping_checked_from_plan(shopping_id):
    items = read_shopping_items()

    if items.empty:
        st.session_state.shopping_checked = {}
        return

    subset = items[items["shopping_id"] == shopping_id]
    checked = {}

    for _, row in subset.iterrows():
        checked[row["product_id"]] = row["durum"] == "alındı"

    st.session_state.shopping_checked = checked


def update_shopping_plan_from_state(shopping_id, complete=False):
    if not shopping_id:
        return

    sessions = read_shopping_sessions()
    items = read_shopping_items()

    if sessions.empty or items.empty:
        return

    mask = items["shopping_id"] == shopping_id
    checked = st.session_state.get("shopping_checked", {})

    for idx, row in items[mask].iterrows():
        product_id = clean_cell(row.get("product_id", ""))
        items.at[idx, "durum"] = "alındı" if checked.get(product_id, False) else "bekliyor"

    subset = items[mask]
    completed_count = int((subset["durum"] == "alındı").sum())
    total_count = len(subset)

    session_mask = sessions["shopping_id"] == shopping_id

    if session_mask.any():
        sessions.loc[session_mask, "tamamlanan_urun"] = str(completed_count)
        sessions.loc[session_mask, "toplam_urun"] = str(total_count)
        sessions.loc[session_mask, "status"] = "tamamlandı" if complete else "devam ediyor"

    write_shopping_sessions(sessions)
    write_shopping_items(items)


def get_pending_shopping_plans():
    sessions = read_shopping_sessions()

    if sessions.empty:
        return sessions

    pending = sessions[sessions["status"].isin(["yapılacak", "devam ediyor"])].copy()
    pending = pending.sort_values(["tarih", "saat"], ascending=[False, False])

    return pending


def enrich_route_categories(route_df):
    """
    Rota ürünlerini ürün ağacındaki kategori bilgisiyle zenginleştirir.
    Amaç: Kaynak altında kategori bölümleri ve ürün kutuları göstermek.
    """
    if route_df.empty:
        return route_df

    df = route_df.copy()

    product_cols = [
        "product_id",
        "ui_seviye_1",
        "ui_seviye_2",
        "ui_seviye_3",
        "ui_seviye_4",
        "marka",
        "urun_adi",
    ]

    master = products_df.copy()
    master = ensure_columns(master, product_cols)[product_cols]

    df = df.merge(
        master,
        on="product_id",
        how="left",
        suffixes=("", "_master")
    )

    def route_category(row):
        parts = [
            clean_cell(row.get("ui_seviye_1", "")),
            clean_cell(row.get("ui_seviye_2", "")),
        ]
        parts = [x for x in parts if x]

        if parts:
            return " > ".join(parts)

        path = clean_cell(row.get("path", ""))
        if path:
            split = [x.strip() for x in path.split(">") if x.strip()]
            return " > ".join(split[:2]) if split else "Diğer"

        return "Diğer"

    def route_subcategory(row):
        parts = [
            clean_cell(row.get("ui_seviye_3", "")),
            clean_cell(row.get("ui_seviye_4", "")),
        ]
        parts = [x for x in parts if x]

        if parts:
            return " > ".join(parts)

        return "Genel"

    df["route_category"] = df.apply(route_category, axis=1)
    df["route_subcategory"] = df.apply(route_subcategory, axis=1)

    return df


def get_route_sort_values(row):
    """
    Rota içinde ürünleri sade ve pratik sıraya dizer.
    Kaynak içinde kategori başlığı ayrı satır açmaz; kategori bilgisi ürün kutusunun içinde görünür.
    """
    category = clean_cell(row.get("route_category", ""))
    subcategory = clean_cell(row.get("route_subcategory", ""))
    name = normalize_for_search(row.get("urun", ""))

    category_order = {
        "Gıda": 1,
        "Gıda > Meyve Sebze": 2,
        "Gıda > Kuru Gıda": 3,
        "Gıda > Şarküteri": 4,
        "Gıda > Et Tavuk Balık": 5,
        "Temizlik": 6,
        "Elektronik": 7,
        "Elektronik > Telefon": 8,
        "Elektronik > Bilgisayar & Tablet": 9,
        "Elektronik > Beyaz Eşya & Ev Aletleri": 10,
        "Elektronik > Ev & Yaşam": 11,
    }

    sub_order = {
        "Sebzeler": 1,
        "Meyveler": 2,
        "Kuru Bakliyat": 3,
        "Temel Gıda": 4,
        "Baharat": 5,
        "Kuruyemiş": 6,
        "İçecekler": 7,
        "Paketli Gıda": 8,
    }

    cat_rank = category_order.get(category, 999)
    sub_rank = sub_order.get(subcategory.split(" > ")[0] if subcategory else "", 999)

    return cat_rank, sub_rank, name


def render_product_route_card(row, shopping_mode=False, unique_key=""):
    product_id = clean_cell(row.get("product_id", ""))
    is_done = bool(st.session_state.shopping_checked.get(product_id, False))

    price_text = format_price(str(row.get("en_ucuz_fiyat", "")))
    saving_text = format_price(str(row.get("tasarruf", "")))
    high_text = format_price(str(row.get("en_yuksek_fiyat", "")))

    if shopping_mode:
        bg = "#dcfce7" if is_done else "#fef9c3"
        border = "#22c55e" if is_done else "#eab308"
        status = "✅ Alındı" if is_done else "🟡 Bekliyor"
    else:
        bg = "#ffffff"
        border = "#e2e8f0"
        status = ""

    icon_html = get_product_icon_html(product_id, str(row.get("urun", "")), size=50)

    st.markdown(
        f"""
        <div style="
            border:2px solid {border};
            background:{bg};
            border-radius:14px;
            padding:8px;
            min-height:168px;
            margin-bottom:6px;
        ">
            {icon_html}
            <div style="font-weight:800; font-size:13px; line-height:1.18;">{row.get('urun', '')}</div>
            <div style="font-size:18px; color:#0f172a; margin-top:8px;"><b>{price_text} ₺</b></div>
            <div style="font-size:10px; color:#64748b; margin-top:3px;">Tasarruf: {saving_text} ₺</div>
            <div style="font-size:10px; color:#64748b;">Yüksek: {high_text} ₺</div>
            <div style="font-size:10px; color:#64748b; margin-top:3px;">{status}</div>
        </div>
        """,
        unsafe_allow_html=True
    )

    if shopping_mode:
        if st.button(
            "Alındı / Geri Al",
            key=safe_key("toggle_shopping_item", product_id, unique_key),
            use_container_width=True
        ):
            st.session_state.shopping_checked[product_id] = not is_done
            update_shopping_plan_from_state(st.session_state.current_shopping_id, complete=False)
            st.rerun()


def get_route_sort_values(row):
    category = clean_cell(row.get("route_category", ""))
    subcategory = clean_cell(row.get("route_subcategory", ""))
    name = normalize_for_search(row.get("urun", ""))

    category_order = {
        "Gıda": 1,
        "Gıda > Meyve Sebze": 2,
        "Gıda > Kuru Gıda": 3,
        "Gıda > Şarküteri": 4,
        "Gıda > Et Tavuk Balık": 5,
        "Temizlik": 6,
        "Elektronik": 7,
        "Elektronik > Telefon": 8,
        "Elektronik > Bilgisayar & Tablet": 9,
        "Elektronik > Beyaz Eşya & Ev Aletleri": 10,
        "Elektronik > Ev & Yaşam": 11,
    }

    sub_order = {
        "Sebzeler": 1,
        "Meyveler": 2,
        "Kuru Bakliyat": 3,
        "Temel Gıda": 4,
        "Baharat": 5,
        "Kuruyemiş": 6,
        "İçecekler": 7,
        "Paketli Gıda": 8,
    }

    first_sub = subcategory.split(" > ")[0] if subcategory else ""
    return (
        category_order.get(category, 999),
        sub_order.get(first_sub, 999),
        name
    )


def render_route_cards(cheapest_df, shopping_mode=False, research_id=""):
    """
    Kaynak > kategori bölümü > yan yana ürün kutuları.
    Kategori adı ürünlerin üstünde bölüm başlığı olarak durur; her ürün üzerinde tekrar yazmaz.
    """
    if cheapest_df.empty:
        return

    route_df = enrich_route_categories(cheapest_df)

    source_order = (
        route_df
        .groupby("source_name")["en_ucuz_fiyat"]
        .sum()
        .sort_values()
        .index
        .tolist()
    )

    products_per_row = 4

    for source_idx, source_name in enumerate(source_order):
        group = route_df[route_df["source_name"] == source_name].copy()

        source_total = round(float(group["en_ucuz_fiyat"].sum()), 2)
        source_saving = round(float(group["tasarruf"].sum()), 2)
        source_type = compact_join(group["source_type"].dropna().unique(), sep=", ")

        st.markdown(
            f"""
            <div style="
                background:#f8fafc;
                border:1px solid #cbd5e1;
                border-radius:16px;
                padding:10px 12px;
                margin:10px 0 8px 0;
            ">
                <div style="font-size:18px; font-weight:900; color:#0f172a;">{source_name}</div>
                <div style="font-size:12px; color:#64748b;">
                    {len(group)} ürün • Toplam {format_price(str(source_total))} ₺ • Tasarruf {format_price(str(source_saving))} ₺
                </div>
            </div>
            """,
            unsafe_allow_html=True
        )

        if source_type:
            st.caption(source_type)

        sort_values = group.apply(get_route_sort_values, axis=1, result_type="expand")
        sort_values.columns = ["_cat_rank", "_sub_rank", "_name_rank"]
        group = pd.concat([group.reset_index(drop=True), sort_values.reset_index(drop=True)], axis=1)
        group = group.sort_values(["_cat_rank", "_sub_rank", "_name_rank"])

        # Kategori + alt kategori bölüm başlıkları.
        section_keys = []
        for _, row in group.iterrows():
            cat = clean_cell(row.get("route_category", "")) or "Diğer"
            sub = clean_cell(row.get("route_subcategory", ""))
            label = cat if not sub or sub == "Genel" else f"{cat} / {sub}"
            if label not in section_keys:
                section_keys.append(label)

        for section_idx, section_label in enumerate(section_keys):
            if " / " in section_label:
                cat, sub = section_label.split(" / ", 1)
                section_group = group[
                    (group["route_category"] == cat) &
                    (group["route_subcategory"] == sub)
                ].copy()
            else:
                section_group = group[
                    (group["route_category"] == section_label) &
                    ((group["route_subcategory"] == "") | (group["route_subcategory"] == "Genel"))
                ].copy()

                # Eğer alt kategorisiz eşleşme yoksa kategoriye ait tüm kalanları al.
                if section_group.empty:
                    section_group = group[group["route_category"] == section_label].copy()

            section_total = round(float(section_group["en_ucuz_fiyat"].sum()), 2)

            st.markdown(
                f"""
                <div style="
                    background:#e2e8f0;
                    border-radius:12px;
                    padding:7px 10px;
                    margin:10px 0 8px 0;
                    font-weight:900;
                    color:#0f172a;
                    font-size:14px;
                ">
                    {section_label} <span style="font-weight:600; color:#475569;">• {len(section_group)} ürün • {format_price(str(section_total))} ₺</span>
                </div>
                """,
                unsafe_allow_html=True
            )

            rows = list(section_group.iterrows())

            for start_idx in range(0, len(rows), products_per_row):
                chunk = rows[start_idx:start_idx + products_per_row]
                cols = st.columns(products_per_row)

                for col_idx, (_, row) in enumerate(chunk):
                    with cols[col_idx]:
                        unique_key = f"{source_idx}_{section_idx}_{start_idx}_{col_idx}"
                        render_product_route_card(row, shopping_mode=shopping_mode, unique_key=unique_key)

        st.markdown("---")


def shopping_items_to_route_df(items_df):
    if items_df.empty:
        return pd.DataFrame()

    rows = []

    for _, row in items_df.iterrows():
        fiyat = parse_price(row.get("fiyat", ""))
        tasarruf = parse_price(row.get("tasarruf", "")) or 0

        rows.append({
            "product_id": row.get("product_id", ""),
            "urun": row.get("urun", ""),
            "birim": "",
            "path": "",
            "en_ucuz_fiyat": fiyat or 0,
            "en_yuksek_fiyat": (fiyat or 0) + tasarruf,
            "tasarruf": tasarruf,
            "source_name": row.get("source_name", ""),
            "source_type": row.get("source_type", ""),
            "tarih": row.get("tarih", ""),
            "saat": row.get("saat", ""),
        })

    return pd.DataFrame(rows)


def render_shopping_mode_screen():
    st.subheader("🛒 Alışveriş Planı")

    shopping_id = clean_cell(st.session_state.get("current_shopping_id", ""))

    if not shopping_id:
        st.warning("Alışveriş planı seçilmedi.")
        if st.button("📋 Yapılacak Alışverişlere Git", use_container_width=True):
            st.session_state.step = "pending_shopping"
            st.rerun()
        return

    items = read_shopping_items()
    plan_items = items[items["shopping_id"] == shopping_id].copy()

    if plan_items.empty:
        st.warning("Bu alışveriş planında ürün yok.")
        return

    load_shopping_checked_from_plan(shopping_id)
    route_df = shopping_items_to_route_df(plan_items)

    session_df = read_shopping_sessions()
    plan = session_df[session_df["shopping_id"] == shopping_id]

    if not plan.empty:
        first = plan.iloc[0]
        st.caption(
            f"{first.get('tarih', '')} {first.get('saat', '')} • "
            f"Durum: {first.get('status', '')} • "
            f"Araştırma: {first.get('research_id', '')}"
        )

    render_route_cards(route_df, shopping_mode=True, research_id="")

    total_items = len(plan_items)
    done_items = sum(1 for pid in plan_items["product_id"].astype(str) if st.session_state.shopping_checked.get(pid, False))

    st.info(f"Tamamlanan: {done_items} / {total_items}")

    c1, c2 = st.columns(2)

    if c1.button("💾 Alışverişi Tamamla ve Kaydet", use_container_width=True, type="primary"):
        update_shopping_plan_from_state(shopping_id, complete=True)
        st.success("Alışveriş tamamlandı olarak kaydedildi.")

    if c2.button("📊 Rotaya Dön", use_container_width=True):
        st.session_state.step = "compare_prices"
        st.rerun()


def render_pending_shopping_screen():
    st.subheader("📋 Yapılacak Alışverişler")

    pending = get_pending_shopping_plans()

    if pending.empty:
        st.info("Bekleyen alışveriş planı yok.")
        if st.button("⬅️ Ana Menü", use_container_width=True):
            st.session_state.step = "research_start"
            st.rerun()
        return

    for i, (_, row) in enumerate(pending.iterrows()):
        st.markdown(
            f"**{row['tarih']} {row['saat']} alışveriş planı**  \n"
            f"Toplam: {format_price(str(row['toplam']))} ₺ • "
            f"Tasarruf: {format_price(str(row['tasarruf']))} ₺ • "
            f"Durum: {row['status']} • "
            f"{row['tamamlanan_urun']}/{row['toplam_urun']} ürün"
        )

        c1, c2 = st.columns(2)

        if c1.button("Alışverişe Devam Et", key=safe_key("continue_plan", row["shopping_id"], i), use_container_width=True):
            st.session_state.current_shopping_id = row["shopping_id"]
            load_shopping_checked_from_plan(row["shopping_id"])
            st.session_state.step = "shopping_mode"
            st.rerun()

        if c2.button("Rotasını Göster", key=safe_key("show_plan_route", row["shopping_id"], i), use_container_width=True):
            st.session_state.compare_research_id = row["research_id"]
            st.session_state.current_shopping_id = row["shopping_id"]
            st.session_state.step = "compare_prices"
            st.rerun()

        st.divider()







def render_compare_screen():
    st.subheader("📊 En Ucuz / Rota")

    if st.button("⬅️ Ürünlere Dön", use_container_width=True):
        st.session_state.step = "product_tree"
        st.rerun()

    saved_all_df = read_saved_price_records()

    if saved_all_df.empty:
        st.warning("Henüz geçmiş fiyat kaydı yok. Birkaç fiş kaydettikten sonra karşılaştırma çalışır.")
        return

    st.markdown("#### Araştırmalar")
    research_id = render_research_history_nav()

    if not research_id:
        st.warning("Araştırma bulunamadı.")
        return

    if "research_id" in saved_all_df.columns:
        saved_df = saved_all_df[saved_all_df["research_id"] == research_id].copy()
    else:
        saved_df = saved_all_df.copy()

    if saved_df.empty:
        st.warning("Bu fiyat araştırması için kayıtlı fiş bulunamadı.")
        return

    current_df = make_current_receipt_df()

    if current_df.empty:
        current_df = make_research_products_df(saved_df)

    if current_df.empty:
        st.info("Önce fişe ürün ekle veya bu araştırma içinde en az bir fiş kaydet.")
        return

    cheapest_df, stop_df, single_stop_df = compute_cheapest_plan(current_df, saved_df)

    if cheapest_df.empty:
        st.warning("Fişteki ürünler için geçmiş fiyat bulunamadı. Aynı ürünlerden fiyat kaydı yaptıkça öneri oluşacak.")
        return

    total_mixed = round(float(cheapest_df["en_ucuz_fiyat"].sum()), 2)
    total_saving = round(float(cheapest_df["tasarruf"].sum()), 2)
    found_count = len(cheapest_df)
    total_count = len(current_df)
    stop_count = cheapest_df["source_name"].nunique()

    st.markdown(f"### En ucuz toplam: {format_price(str(total_mixed))} ₺")
    st.success(f"Tahmini toplam tasarruf: {format_price(str(total_saving))} ₺")
    st.caption(f"{found_count} / {total_count} ürün • {stop_count} durak")

    if st.button("🛒 Alışverişe Başla", use_container_width=True, type="primary"):
        shopping_id = get_or_create_shopping_plan(cheapest_df, research_id)
        st.session_state.current_shopping_id = shopping_id
        load_shopping_checked_from_plan(shopping_id)
        st.session_state.step = "shopping_mode"
        st.rerun()

    st.markdown("---")
    st.markdown("## Rota bölümleri")
    st.caption("Neyi nereden alacağını kaynak kaynak gösterir.")

    render_route_cards(cheapest_df, shopping_mode=False, research_id=research_id)

    if not single_stop_df.empty:
        with st.expander("Tek durak alternatifi"):
            best_single = single_stop_df.iloc[0]
            st.success(
                f"{best_single['source_name']} • "
                f"{int(best_single['bulunan_urun'])}/{int(best_single['toplam_urun'])} ürün • "
                f"Toplam: {format_price(str(best_single['toplam']))} ₺"
            )

            for _, row in single_stop_df.head(10).iterrows():
                st.markdown(
                    f"**{row['source_name']}** — "
                    f"{int(row['bulunan_urun'])}/{int(row['toplam_urun'])} ürün, "
                    f"eksik: {int(row['eksik_urun'])}, "
                    f"toplam: {format_price(str(row['toplam']))} ₺"
                )

    st.markdown("---")
    st.caption("Not: Bu öneri sadece seçili fiyat araştırmasındaki kayıtlara göre çalışır.")





# =========================================================
# 12. SABİT ALT MENÜ
# =========================================================

def render_fixed_bottom_nav():
    if st.session_state.step == "location":
        return

    st.markdown('<div class="bottom-spacer"></div>', unsafe_allow_html=True)

    st.markdown('<div class="fixed-bottom-nav">', unsafe_allow_html=True)

    b1, b2, b3 = st.columns(3)

    if b1.button("🏠 Ana Menü", use_container_width=True, key="bottom_home"):
        st.session_state.step = "research_start"
        st.rerun()

    if b2.button("📊 En Ucuz / Rota", use_container_width=True, key="bottom_compare"):
        st.session_state.step = "compare_prices"
        st.rerun()

    if st.session_state.get("research_active", False):
        if b3.button("🏁 Araştırmayı Bitir", use_container_width=True, key="bottom_finish_research"):
            finish_research_session()
            st.rerun()
    else:
        if b3.button("📋 Yapılacaklar", use_container_width=True, key="bottom_pending_shopping"):
            st.session_state.step = "pending_shopping"
            st.rerun()

    st.markdown('</div>', unsafe_allow_html=True)


# =========================================================
# 11. ANA ROUTER
# =========================================================

if products_df.empty:
    st.error("products_master_clean.csv bulunamadı veya boş.")
    st.stop()

if st.session_state.step == "location":
    render_location_screen()

elif st.session_state.step == "research_start":
    render_research_start_screen()

elif st.session_state.step == "source_smart":
    render_smart_source_screen()

elif st.session_state.step == "source_type":
    render_source_type_screen()

elif st.session_state.step == "source_name":
    render_source_name_screen()

elif st.session_state.step == "product_tree":
    render_product_tree_screen()

elif st.session_state.step == "price_entry":
    render_price_entry_screen()

elif st.session_state.step == "compare_prices":
    render_compare_screen()

elif st.session_state.step == "shopping_mode":
    render_shopping_mode_screen()

elif st.session_state.step == "pending_shopping":
    render_pending_shopping_screen()

else:
    st.session_state.step = "location"
    st.rerun()

render_fixed_bottom_nav()
