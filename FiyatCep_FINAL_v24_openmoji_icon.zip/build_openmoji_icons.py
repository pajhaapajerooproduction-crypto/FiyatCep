import os
import re
import time
import urllib.request
import zipfile
from pathlib import Path

import pandas as pd

DATA_PACKAGE_ZIP = "FiyatCep_Data_Paketi_v9.zip"
ICON_MAP_FILE = "icon_map_openmoji.csv"
ICON_DIR = Path("icons") / "openmoji"

TR_MAP = str.maketrans({
    "ı": "i", "İ": "i", "ş": "s", "ğ": "g", "ü": "u",
    "ö": "o", "ç": "c", "â": "a", "î": "i", "û": "u"
})

RULES = [
    (["domates"], "1F345", "tomato", "🍅"),
    (["patates"], "1F954", "potato", "🥔"),
    (["salatalik", "hiyar"], "1F952", "cucumber", "🥒"),
    (["taze sogan", "sogan"], "1F9C5", "onion", "🧅"),
    (["limon"], "1F34B", "lemon", "🍋"),
    (["biber", "carliston", "kapya"], "1F336", "hot-pepper", "🌶️"),
    (["patlican"], "1F346", "eggplant", "🍆"),
    (["pirasa"], "1F96C", "leafy-green", "🥬"),
    (["havuc"], "1F955", "carrot", "🥕"),
    (["roka", "kivircik", "marul"], "1F96C", "leafy-green", "🥬"),
    (["maydanoz", "nane", "kekik"], "1F33F", "herb", "🌿"),
    (["sarimsak", "sarmisak"], "1F9C4", "garlic", "🧄"),
    (["elma"], "1F34E", "red-apple", "🍎"),
    (["armut", "ayva"], "1F350", "pear", "🍐"),
    (["portakal"], "1F34A", "orange", "🍊"),
    (["karpuz"], "1F349", "watermelon", "🍉"),
    (["cilek"], "1F353", "strawberry", "🍓"),
    (["erik"], "1FAD0", "blueberries", "🟣"),
    (["kiraz"], "1F352", "cherries", "🍒"),
    (["nar"], "1F34E", "pomegranate-fallback", "🔴"),
    (["sut"], "1F95B", "glass-of-milk", "🥛"),
    (["peynir"], "1F9C0", "cheese-wedge", "🧀"),
    (["yumurta"], "1F95A", "egg", "🥚"),
    (["et", "kiyma"], "1F969", "cut-of-meat", "🥩"),
    (["tavuk"], "1F357", "poultry-leg", "🍗"),
    (["balik"], "1F41F", "fish", "🐟"),
    (["ekmek"], "1F35E", "bread", "🍞"),
    (["makarna"], "1F35D", "spaghetti", "🍝"),
    (["pirinc"], "1F35A", "cooked-rice", "🍚"),
    (["mercimek", "fasulye", "nohut", "bakliyat"], "1FAD8", "beans", "🫘"),
    (["cay"], "1F375", "teacup", "🍵"),
    (["kahve"], "2615", "coffee", "☕"),
    (["telefon", "iphone", "samsung", "xiaomi", "tecno", "vivo"], "1F4F1", "mobile-phone", "📱"),
    (["laptop", "macbook", "notebook", "dizustu"], "1F4BB", "laptop", "💻"),
    (["tablet"], "1F4F1", "tablet-fallback", "📱"),
    (["monitor"], "1F5A5", "desktop-computer", "🖥️"),
    (["klavye"], "2328", "keyboard", "⌨️"),
    (["mouse"], "1F5B1", "computer-mouse", "🖱️"),
    (["buzdolabi"], "1F9CA", "ice-cube-fridge-fallback", "🧊"),
    (["camasir makinesi"], "1F9FA", "basket-laundry-fallback", "🧺"),
    (["bulasik makinesi"], "1F37D", "plate-cutlery-fallback", "🍽️"),
    (["firin", "mikrodalga"], "1F525", "fire-oven-fallback", "🔥"),
    (["supurge", "dreame"], "1F9F9", "broom", "🧹"),
    (["utu"], "267F", "iron-fallback", "♨️"),
    (["airfryer", "fritoz"], "1F35F", "fries-fryer-fallback", "🍟"),
    (["mikser", "blender", "rondo", "mutfak robotu", "mutfak sefi"], "1F963", "bowl-with-spoon", "🥣"),
    (["kettle", "su isiticisi", "cay makinesi"], "2615", "hot-beverage", "☕"),
    (["dis fircasi"], "1FAA5", "toothbrush", "🪥"),
    (["tras", "epilasyon"], "1FA92", "razor", "🪒"),
    (["sampuan", "sabun", "deterjan", "temizleyici", "yumusatici"], "1F9F4", "lotion-bottle", "🧴"),
    (["tuvalet kagidi", "pecete", "havlu"], "1F9FB", "roll-of-paper", "🧻"),
    (["sunger", "sünger"], "1F9FD", "sponge", "🧽"),
    (["akaryakit", "benzin", "motorin", "lpg"], "26FD", "fuel-pump", "⛽"),
]

CATEGORY_RULES = [
    ("gida", "1F6D2", "shopping-cart", "🛒"),
    ("meyve", "1F9FA", "basket", "🛒"),
    ("sebze", "1F9FA", "basket", "🛒"),
    ("elektronik", "1F50C", "electric-plug", "🔌"),
    ("temizlik", "1F9FD", "sponge", "🧽"),
]

def normalize(text):
    text = "" if pd.isna(text) else str(text)
    text = text.lower().translate(TR_MAP)
    text = re.sub(r"[^a-z0-9]+", " ", text)
    return re.sub(r"\s+", " ", text).strip()

def infer(row):
    text = " ".join(str(row.get(c, "")) for c in [
        "urun_adi", "marka", "model", "ui_path",
        "ui_seviye_1", "ui_seviye_2", "ui_seviye_3", "ui_seviye_4"
    ])
    n = normalize(text)
    for keys, codepoint, query, emoji in RULES:
        if any(k in n for k in keys):
            return codepoint, query, emoji
    for key, codepoint, query, emoji in CATEGORY_RULES:
        if key in n:
            return codepoint, query, emoji
    return "1F6D2", "shopping-cart", "🛒"

def read_products():
    if Path("products_master_clean.csv").exists():
        return pd.read_csv("products_master_clean.csv", dtype=str, encoding="utf-8-sig").fillna("")

    if Path(DATA_PACKAGE_ZIP).exists():
        with zipfile.ZipFile(DATA_PACKAGE_ZIP, "r") as z:
            with z.open("products_master_clean.csv") as f:
                return pd.read_csv(f, dtype=str, encoding="utf-8-sig").fillna("")

    raise FileNotFoundError("products_master_clean.csv veya FiyatCep_Data_Paketi_v9.zip bulunamadı.")

def download_openmoji(codepoint):
    codepoint = str(codepoint).upper().strip()
    out_path = ICON_DIR / f"{codepoint}.svg"

    if out_path.exists() and out_path.stat().st_size > 0:
        return str(out_path).replace("\\", "/")

    # OpenMoji resmi GitHub dosya yolu. Iconify search yerine doğrudan codepoint indiriyoruz.
    urls = [
        f"https://raw.githubusercontent.com/hfg-gmuend/openmoji/master/color/svg/{codepoint}.svg",
        f"https://raw.githubusercontent.com/hfg-gmuend/openmoji/master/color/svg/{codepoint.lower()}.svg",
    ]

    last_error = None
    for url in urls:
        try:
            with urllib.request.urlopen(url, timeout=25) as resp:
                data = resp.read()
            if data.strip().startswith(b"<svg") or b"<svg" in data[:200]:
                ICON_DIR.mkdir(parents=True, exist_ok=True)
                out_path.write_bytes(data)
                return str(out_path).replace("\\", "/")
        except Exception as e:
            last_error = e

    raise RuntimeError(f"{codepoint} indirilemedi: {last_error}")

def main():
    products = read_products()
    ICON_DIR.mkdir(parents=True, exist_ok=True)

    rows = []
    code_cache = {}

    for _, row in products.iterrows():
        product_id = str(row.get("product_id", "")).strip()
        if not product_id:
            continue

        codepoint, query, emoji = infer(row)
        icon_file = ""
        matched = "fallback"

        try:
            if codepoint in code_cache:
                icon_file = code_cache[codepoint]
            else:
                icon_file = download_openmoji(codepoint)
                code_cache[codepoint] = icon_file
            matched = "openmoji"
        except Exception as e:
            print(f"Uyarı: {product_id} / {row.get('urun_adi', '')} / {codepoint}: {e}")
            time.sleep(0.05)

        rows.append({
            "product_id": product_id,
            "urun_adi": row.get("urun_adi", ""),
            "category": row.get("ui_path", ""),
            "icon_query": query,
            "openmoji_codepoint": codepoint,
            "icon_id": f"openmoji:{codepoint.lower()}",
            "icon_file": icon_file if icon_file else "",
            "emoji_fallback": emoji,
            "matched": matched,
        })

    pd.DataFrame(rows).to_csv(ICON_MAP_FILE, index=False, encoding="utf-8-sig")
    print(f"Tamamlandı: {ICON_MAP_FILE}")
    print(f"İkon klasörü: {ICON_DIR}")
    print("Şimdi uygulamayı yeniden çalıştır: streamlit run main.py")

if __name__ == "__main__":
    main()
