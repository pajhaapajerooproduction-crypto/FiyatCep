import os
import re
import uuid
import zipfile
from datetime import datetime

import pandas as pd
import streamlit as st

try:
    import folium
    from streamlit_folium import st_folium
    HAS_MAP = True
except Exception:
    HAS_MAP = False


# =========================================================
# FİYATCEP - ADİSYON/FİŞ MANTIĞI V1
# =========================================================
# Gerekli dosyalar:
# - products_master_clean.csv
# - source_master.csv
# Opsiyonel:
# - product_specs.csv veya product_specs_template.csv
# - data_reference.csv veya data_reference_template.csv
#
# Not:
# Bu kod kategori/mağaza/marka UYDURMAZ.
# Ekranda görünen ürün ağacı products_master_clean.csv içinden gelir.
# Kaynak listesi source_master.csv içinden gelir.
# Kullanıcı isterse elle kaynak yazabilir; bu kullanıcı girdisidir, otomatik uydurma değildir.
# =========================================================


# =========================================================
# 1. AYARLAR
# =========================================================

PRODUCTS_FILE = "products_master_clean.csv"
SOURCE_FILE = "source_master.csv"

SPECS_FILE = "product_specs.csv"
SPECS_TEMPLATE_FILE = "product_specs_template.csv"

DATA_REFERENCE_FILE = "data_reference.csv"
DATA_REFERENCE_TEMPLATE_FILE = "data_reference_template.csv"

RECEIPT_HEADER_FILE = "receipt_header.csv"
PRICE_RECORDS_FILE = "price_records.csv"

DATA_PACKAGE_ZIP = "FiyatCep_Data_Paketi_v9.zip"

RECEIPT_HEADER_COLUMNS = [
    "receipt_id",
    "tarih",
    "saat",
    "source_id",
    "source_type",
    "source_name",
    "konum_lat",
    "konum_lon",
    "konum_dogrulandi",
    "toplam_kalem",
    "not",
]

PRICE_RECORD_COLUMNS = [
    "receipt_id",
    "line_id",
    "tarih",
    "saat",
    "source_id",
    "source_type",
    "source_name",
    "product_id",
    "urun_adi",
    "marka",
    "model",
    "varyant",
    "birim",
    "fiyat",
    "konum_lat",
    "konum_lon",
    "not",
]


st.set_page_config(
    page_title="FiyatCep",
    page_icon="🧾",
    layout="centered",
    initial_sidebar_state="collapsed",
)


# =========================================================
# 2. GENEL YARDIMCI FONKSİYONLAR
# =========================================================

def clean_cell(value):
    if pd.isna(value):
        return ""
    text = str(value).strip()
    if text.lower() in ["nan", "none", "null", "<na>"]:
        return ""
    return text


def normalize_for_search(text):
    text = clean_cell(text).lower()

    tr_map = str.maketrans({
        "ı": "i",
        "İ": "i",
        "ş": "s",
        "ğ": "g",
        "ü": "u",
        "ö": "o",
        "ç": "c",
        "â": "a",
        "î": "i",
        "û": "u",
    })

    text = text.translate(tr_map)
    text = re.sub(r"[^a-z0-9]+", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def compact_join(values, sep=" "):
    output = []
    seen = set()

    for value in values:
        value = clean_cell(value)
        key = normalize_for_search(value)

        if value and key and key not in seen:
            output.append(value)
            seen.add(key)

    return sep.join(output)


def ensure_columns(df, columns):
    for col in columns:
        if col not in df.columns:
            df[col] = ""
    return df


def safe_key(prefix, value, idx=""):
    raw = f"{prefix}_{value}_{idx}"
    return normalize_for_search(raw).replace(" ", "_")[:180]


def parse_price(value):
    value = clean_cell(value)

    if not value:
        return None

    value = value.replace("₺", "").replace("TL", "").replace("tl", "")
    value = value.replace(".", "").replace(",", ".") if "," in value else value

    try:
        price = float(value)
        if price <= 0:
            return None
        return round(price, 2)
    except Exception:
        return None


def format_price(value):
    price = parse_price(value)

    if price is None:
        return ""

    return f"{price:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")



def read_saved_price_records():
    if not os.path.exists(PRICE_RECORDS_FILE):
        return pd.DataFrame(columns=PRICE_RECORD_COLUMNS)

    try:
        df = pd.read_csv(PRICE_RECORDS_FILE, dtype=str, encoding="utf-8-sig")
    except UnicodeDecodeError:
        df = pd.read_csv(PRICE_RECORDS_FILE, dtype=str, encoding="cp1254")
    except Exception:
        return pd.DataFrame(columns=PRICE_RECORD_COLUMNS)

    df = ensure_columns(df, PRICE_RECORD_COLUMNS)

    for col in PRICE_RECORD_COLUMNS:
        df[col] = df[col].apply(clean_cell)

    df["price_float"] = df["fiyat"].apply(parse_price)
    df = df[df["price_float"].notna()].copy()

    return df


def make_current_receipt_df():
    rows = []

    for item in st.session_state.receipt_items:
        rows.append({
            "product_id": clean_cell(item.get("product_id", "")),
            "urun_adi": clean_cell(item.get("urun_adi", "")),
            "title": clean_cell(item.get("title", "")),
            "marka": clean_cell(item.get("marka", "")),
            "model": clean_cell(item.get("model", "")),
            "birim": clean_cell(item.get("birim", "")),
            "path": clean_cell(item.get("path", "")),
        })

    return pd.DataFrame(rows)


def compute_cheapest_plan(current_df, saved_df):
    """
    Mevcut fişteki ürünler için geçmiş fiyat kayıtlarından:
    - ürün bazında en ucuz kaynak
    - kaynak/durak bazında alınacak ürün listesi
    - tek durak alternatifleri
    üretir.
    """
    if current_df.empty or saved_df.empty:
        return pd.DataFrame(), pd.DataFrame(), pd.DataFrame()

    current_ids = current_df["product_id"].dropna().astype(str).tolist()
    relevant = saved_df[saved_df["product_id"].isin(current_ids)].copy()

    if relevant.empty:
        return pd.DataFrame(), pd.DataFrame(), pd.DataFrame()

    relevant = relevant.sort_values(["product_id", "price_float", "tarih", "saat"], ascending=[True, True, False, False])

    cheapest_rows = []
    for product_id, group in relevant.groupby("product_id"):
        best = group.iloc[0].to_dict()
        product_info = current_df[current_df["product_id"] == product_id].iloc[0].to_dict()

        cheapest_rows.append({
            "product_id": product_id,
            "urun": product_info.get("title") or product_info.get("urun_adi"),
            "birim": product_info.get("birim", ""),
            "path": product_info.get("path", ""),
            "en_ucuz_fiyat": best.get("price_float"),
            "source_name": best.get("source_name", ""),
            "source_type": best.get("source_type", ""),
            "tarih": best.get("tarih", ""),
            "saat": best.get("saat", ""),
        })

    cheapest_df = pd.DataFrame(cheapest_rows)

    stop_rows = []
    if not cheapest_df.empty:
        for source_name, group in cheapest_df.groupby("source_name"):
            stop_rows.append({
                "source_name": source_name,
                "source_type": compact_join(group["source_type"].dropna().unique(), sep=", "),
                "urun_sayisi": len(group),
                "toplam": round(float(group["en_ucuz_fiyat"].sum()), 2),
                "urunler": " | ".join(group["urun"].astype(str).tolist()),
            })

    stop_df = pd.DataFrame(stop_rows)
    if not stop_df.empty:
        stop_df = stop_df.sort_values(["toplam", "urun_sayisi"], ascending=[True, False])

    # Tek durak: aynı kaynakta geçmiş fiyatı bulunan ürünleri ve toplamı gösterir.
    single_stop_rows = []
    for source_name, group in relevant.groupby("source_name"):
        best_per_product = group.sort_values("price_float").groupby("product_id").head(1)
        single_stop_rows.append({
            "source_name": source_name,
            "source_type": compact_join(best_per_product["source_type"].dropna().unique(), sep=", "),
            "bulunan_urun": best_per_product["product_id"].nunique(),
            "toplam_urun": len(current_df),
            "eksik_urun": len(current_df) - best_per_product["product_id"].nunique(),
            "toplam": round(float(best_per_product["price_float"].sum()), 2),
        })

    single_stop_df = pd.DataFrame(single_stop_rows)

    if not single_stop_df.empty:
        single_stop_df = single_stop_df.sort_values(
            ["eksik_urun", "toplam", "bulunan_urun"],
            ascending=[True, True, False]
        )

    return cheapest_df, stop_df, single_stop_df


def format_product_title(row):
    marka = clean_cell(row.get("marka", ""))
    model = clean_cell(row.get("model", ""))
    urun_adi = clean_cell(row.get("urun_adi", ""))

    base = model or urun_adi or marka

    if not base:
        base = urun_adi

    if marka and normalize_for_search(marka) not in normalize_for_search(base):
        base = compact_join([marka, base])

    words = base.split()

    if len(words) % 2 == 0:
        half = len(words) // 2
        if [w.lower() for w in words[:half]] == [w.lower() for w in words[half:]]:
            base = " ".join(words[:half])

    if marka.lower() == "apple":
        base = re.sub(r"\b[A-Z0-9]{4,}TU/A\b", "", base)
        base = re.sub(r"\bM[A-Z0-9]{3,}/A\b", "", base)
        base = re.sub(r"\b[A-Z0-9]{6,}/A\b", "", base)

    base = re.sub(r"\s+", " ", base).strip()

    if len(base) > 120:
        base = base[:117] + "..."

    return base or "İsimsiz Ürün"


def format_product_subtitle(row):
    return compact_join([
        row.get("sektor", ""),
        row.get("ana_kategori", ""),
        row.get("alt_kategori", ""),
        row.get("urun_turu", ""),
    ], sep=" > ")


def get_today_strings():
    now = datetime.now()
    return now.strftime("%Y-%m-%d"), now.strftime("%H:%M:%S")


def append_csv(file_path, rows, columns):
    if not rows:
        return

    df_new = pd.DataFrame(rows)
    df_new = ensure_columns(df_new, columns)[columns]

    if os.path.exists(file_path):
        try:
            df_old = pd.read_csv(file_path, dtype=str, encoding="utf-8-sig")
            all_cols = list(dict.fromkeys(list(df_old.columns) + columns))

            df_old = ensure_columns(df_old, all_cols)
            df_new = ensure_columns(df_new, all_cols)

            df_out = pd.concat([df_old[all_cols], df_new[all_cols]], ignore_index=True)

        except Exception:
            df_out = df_new
    else:
        df_out = df_new

    df_out.to_csv(file_path, index=False, encoding="utf-8-sig")


# =========================================================
# 3. DOSYA OKUMA
# =========================================================

def read_csv_smart(file_name):
    """
    Önce FiyatCep_Data_Paketi_v8.zip içindeki güncel dosyayı okur.
    Böylece klasörde eski products_master_clean.csv kalmışsa menüyü bozmaz.
    Zip yoksa aynı klasördeki CSV'ye düşer.
    """

    if os.path.exists(DATA_PACKAGE_ZIP):
        try:
            with zipfile.ZipFile(DATA_PACKAGE_ZIP) as z:
                if file_name in z.namelist():
                    with z.open(file_name) as f:
                        return pd.read_csv(f, dtype=str, encoding="utf-8-sig")
        except Exception as e:
            st.error(f"{DATA_PACKAGE_ZIP} içinden {file_name} okunamadı: {e}")
            return pd.DataFrame()

    if os.path.exists(file_name):
        try:
            return pd.read_csv(file_name, dtype=str, encoding="utf-8-sig")
        except UnicodeDecodeError:
            return pd.read_csv(file_name, dtype=str, encoding="cp1254")
        except Exception as e:
            st.error(f"{file_name} okunamadı: {e}")
            return pd.DataFrame()

    return pd.DataFrame()


@st.cache_data
def load_products():
    df = read_csv_smart(PRODUCTS_FILE)

    required = [
        "product_id",
        "sektor",
        "ana_kategori",
        "alt_kategori",
        "urun_turu",
        "marka",
        "model",
        "urun_adi",
        "birim",
        "icon",
        "photo_thumb_path",
        "photo_detail_path",
        "ui_seviye_1",
        "ui_seviye_2",
        "ui_seviye_3",
        "ui_seviye_4",
        "ui_seviye_5",
        "ui_path",
    ]

    df = ensure_columns(df, required)

    for col in required:
        df[col] = df[col].apply(clean_cell)

    # ui seviyeleri boşsa temel kolonlardan doldur.
    df["ui_seviye_1"] = df["ui_seviye_1"].where(df["ui_seviye_1"] != "", df["sektor"])
    df["ui_seviye_2"] = df["ui_seviye_2"].where(df["ui_seviye_2"] != "", df["ana_kategori"])
    df["ui_seviye_3"] = df["ui_seviye_3"].where(df["ui_seviye_3"] != "", df["alt_kategori"])
    df["ui_seviye_4"] = df["ui_seviye_4"].where(df["ui_seviye_4"] != "", df["urun_turu"])
    df["ui_seviye_5"] = df["ui_seviye_5"].where(df["ui_seviye_5"] != "", df["marka"])

    # Tamamen boş seviyeleri normalize et.
    for col in ["ui_seviye_1", "ui_seviye_2", "ui_seviye_3", "ui_seviye_4", "ui_seviye_5"]:
        df[col] = df[col].apply(clean_cell)

    df = df[df["product_id"] != ""]
    df = df[df["urun_adi"] != ""]
    df = df.drop_duplicates(subset=["product_id"], keep="first").reset_index(drop=True)

    search_cols = [
        "product_id",
        "sektor",
        "ana_kategori",
        "alt_kategori",
        "urun_turu",
        "marka",
        "model",
        "urun_adi",
        "birim",
        "ui_path",
    ]

    df["search_text"] = (
        df[search_cols]
        .fillna("")
        .astype(str)
        .agg(" ".join, axis=1)
        .apply(normalize_for_search)
    )

    return df


@st.cache_data
def load_sources():
    df = read_csv_smart(SOURCE_FILE)

    required = [
        "source_id",
        "source_type",
        "source_name",
        "related_brand",
        "sector_scope",
        "category_scope",
        "product_count",
        "is_brand_store",
        "is_user_created",
        "note",
    ]

    df = ensure_columns(df, required)

    for col in required:
        df[col] = df[col].apply(clean_cell)

    df = df[df["source_name"] != ""]
    df = df.drop_duplicates(subset=["source_id", "source_type", "source_name"], keep="first")
    df = df.reset_index(drop=True)

    return df


@st.cache_data
def load_specs():
    df = read_csv_smart(SPECS_FILE)

    if df.empty:
        df = read_csv_smart(SPECS_TEMPLATE_FILE)

    required = ["product_id", "ozellik_adi", "ozellik_degeri", "note"]
    df = ensure_columns(df, required)

    for col in required:
        df[col] = df[col].apply(clean_cell)

    df = df[
        (df["product_id"] != "") &
        (df["ozellik_adi"] != "") &
        (df["ozellik_degeri"] != "")
    ]

    return df[required].drop_duplicates().reset_index(drop=True)


@st.cache_data
def load_reference():
    df = read_csv_smart(DATA_REFERENCE_FILE)

    if df.empty:
        df = read_csv_smart(DATA_REFERENCE_TEMPLATE_FILE)

    required = [
        "product_id",
        "veri_kaynak_adi",
        "referans_fiyat",
        "para_birimi",
        "urun_linki",
        "gorsel_linki",
        "note",
    ]

    df = ensure_columns(df, required)

    for col in required:
        df[col] = df[col].apply(clean_cell)

    df = df[df["product_id"] != ""]

    return df[required].reset_index(drop=True)


products_df = load_products()
sources_df = load_sources()
specs_df = load_specs()
reference_df = load_reference()


# =========================================================
# 4. ÜRÜN / KAYNAK FONKSİYONLARI
# =========================================================

LEVEL_COLS = [
    "ui_seviye_1",
    "ui_seviye_2",
    "ui_seviye_3",
    "ui_seviye_4",
    "ui_seviye_5",
]

TREE_OPTION_ORDER = {
    "ui_seviye_1": ["Gıda", "Elektronik", "Temizlik"],
    "gida_ui_seviye_2": [
        "Meyve Sebze",
        "Kuru Gıda",
        "Şarküteri",
        "Et Tavuk Balık",
    ],
    "meyve_sebze_ui_seviye_3": [
        "Sebzeler",
        "Meyveler",
    ],
    "kuru_gida_ui_seviye_3": [
        "Kuru Bakliyat",
        "Temel Gıda",
        "Baharat",
        "Kuruyemiş",
        "İçecekler",
        "Paketli Gıda",
    ],
    "elektronik_ui_seviye_2": [
        "Telefon",
        "Bilgisayar & Tablet",
        "Beyaz Eşya & Ev Aletleri",
        "Ev & Yaşam",
        "Ağız & Diş Bakımı",
        "Saç Bakım Cihazları",
        "Tıraş & Epilasyon",
        "Kişisel Bakım",
    ],
    "bilgisayar_ui_seviye_3": [
        "Masaüstü/PC",
        "Dizüstü/Laptop",
        "Tablet",
        "Monitör",
        "Diğerleri",
    ],
}

PRODUCT_ORDER = {
    "sebzeler": [
        "domates",
        "patates",
        "salatalik",
        "taze sogan",
        "limon",
        "biber",
        "patlican",
        "pirasa",
        "havuc",
        "roka",
        "kivircik",
        "maydanoz",
        "sarmisak",
        "sarimsak",
    ],
    "meyveler": [
        "elma",
        "armut",
        "portakal",
        "ayva",
        "karpuz",
        "cilek",
        "erik",
        "kiraz",
        "nar",
    ],
}

def product_order_score(row):
    level_1 = clean_cell(st.session_state.get("level_1", ""))
    level_2 = clean_cell(st.session_state.get("level_2", ""))
    level_3 = clean_cell(st.session_state.get("level_3", ""))

    if level_1 != "Gıda" or level_2 != "Meyve Sebze":
        return 9999

    name = normalize_for_search(row.get("urun_adi", ""))

    if level_3 == "Sebzeler":
        order = PRODUCT_ORDER["sebzeler"]
    elif level_3 == "Meyveler":
        order = PRODUCT_ORDER["meyveler"]
    else:
        return 9999

    for i, key in enumerate(order):
        key_norm = normalize_for_search(key)

        if name == key_norm:
            return i * 100

        if name.startswith(key_norm + " ") or key_norm in name:
            return i * 100 + 10

        if key_norm == "taze sogan" and ("sogan taze" in name or "taze sogan" in name):
            return i * 100

    return 9999

def sort_tree_options(options, level_col):
    options = [clean_cell(x) for x in options if clean_cell(x)]

    if level_col == "ui_seviye_1":
        order = TREE_OPTION_ORDER["ui_seviye_1"]
    elif level_col == "ui_seviye_2" and st.session_state.get("level_1") == "Gıda":
        order = TREE_OPTION_ORDER["gida_ui_seviye_2"]
    elif level_col == "ui_seviye_3" and st.session_state.get("level_1") == "Gıda" and st.session_state.get("level_2") == "Meyve Sebze":
        order = TREE_OPTION_ORDER["meyve_sebze_ui_seviye_3"]
    elif level_col == "ui_seviye_3" and st.session_state.get("level_1") == "Gıda" and st.session_state.get("level_2") == "Kuru Gıda":
        order = TREE_OPTION_ORDER["kuru_gida_ui_seviye_3"]
    elif level_col == "ui_seviye_2" and st.session_state.get("level_1") == "Elektronik":
        order = TREE_OPTION_ORDER["elektronik_ui_seviye_2"]
    elif level_col == "ui_seviye_3" and st.session_state.get("level_1") == "Elektronik" and st.session_state.get("level_2") == "Bilgisayar & Tablet":
        order = TREE_OPTION_ORDER["bilgisayar_ui_seviye_3"]
    else:
        order = []

    order_map = {name: i for i, name in enumerate(order)}

    return sorted(
        options,
        key=lambda x: (order_map.get(x, 999), normalize_for_search(x))
    )


def get_filtered_products():
    df = products_df.copy()

    for i, col in enumerate(LEVEL_COLS, start=1):
        selected = clean_cell(st.session_state.get(f"level_{i}", ""))
        if selected:
            df = df[df[col] == selected]

    return df


def get_next_level_options():
    df = get_filtered_products()

    for i, col in enumerate(LEVEL_COLS, start=1):
        selected = clean_cell(st.session_state.get(f"level_{i}", ""))
        if not selected:
            options = [
                clean_cell(x)
                for x in df[col].dropna().unique()
                if clean_cell(x)
            ]
            options = sort_tree_options(options, col)
            return i, col, options

    return None, None, []


def reset_tree(from_level=1):
    for i in range(from_level, 6):
        st.session_state[f"level_{i}"] = ""

    st.session_state.product_list_limit = 12


def get_deepest_selected_level():
    deepest = 0

    for i in range(1, 6):
        if clean_cell(st.session_state.get(f"level_{i}", "")):
            deepest = i

    return deepest


def go_up_one_level():
    deepest = get_deepest_selected_level()

    if deepest <= 1:
        reset_tree(1)
    else:
        reset_tree(deepest)


def get_specs_preview(product_id, max_items=4):
    if specs_df.empty:
        return ""

    subset = specs_df[specs_df["product_id"] == product_id]

    if subset.empty:
        return ""

    items = []
    for _, row in subset.head(max_items).iterrows():
        items.append(f"{row['ozellik_adi']}: {row['ozellik_degeri']}")

    return " • ".join(items)


def get_reference_preview(product_id):
    if reference_df.empty:
        return ""

    subset = reference_df[reference_df["product_id"] == product_id]

    if subset.empty:
        return ""

    first = subset.iloc[0]
    kaynak = clean_cell(first.get("veri_kaynak_adi", ""))
    fiyat = clean_cell(first.get("referans_fiyat", ""))
    para = clean_cell(first.get("para_birimi", "")) or "₺"

    return compact_join([kaynak, f"{fiyat} {para}" if fiyat else ""], sep=" / ")


def source_label(row):
    return compact_join([
        row.get("source_name", ""),
        row.get("source_type", ""),
    ], sep=" • ")


def select_source_from_row(row):
    st.session_state.source_id = clean_cell(row.get("source_id", ""))
    st.session_state.source_type = clean_cell(row.get("source_type", ""))
    st.session_state.source_name = clean_cell(row.get("source_name", ""))
    st.session_state.source_auto_selected = False
    st.session_state.step = "product_tree"
    reset_tree(1)


def select_manual_source(source_type, source_name):
    st.session_state.source_id = "USER_" + normalize_for_search(source_name).replace(" ", "_")[:50]
    st.session_state.source_type = clean_cell(source_type) or "Kullanıcı Girdisi"
    st.session_state.source_name = clean_cell(source_name)
    st.session_state.source_auto_selected = False
    st.session_state.step = "product_tree"
    reset_tree(1)


def add_to_receipt(product_row):
    product_id = clean_cell(product_row.get("product_id", ""))

    already = [
        item for item in st.session_state.receipt_items
        if item["product_id"] == product_id
    ]

    if already:
        st.toast("Bu ürün fişte zaten var.")
        return

    item = {
        "line_id": "L" + str(len(st.session_state.receipt_items) + 1).zfill(3),
        "product_id": product_id,
        "urun_adi": clean_cell(product_row.get("urun_adi", "")),
        "marka": clean_cell(product_row.get("marka", "")),
        "model": clean_cell(product_row.get("model", "")),
        "varyant": "",
        "birim": clean_cell(product_row.get("birim", "")) or "Adet",
        "title": format_product_title(product_row),
        "path": format_product_subtitle(product_row),
        "sektor": clean_cell(product_row.get("sektor", "")),
        "ana_kategori": clean_cell(product_row.get("ana_kategori", "")),
        "alt_kategori": clean_cell(product_row.get("alt_kategori", "")),
        "urun_turu": clean_cell(product_row.get("urun_turu", "")),
        "fiyat": "",
        "not": "",
    }

    st.session_state.receipt_items.append(item)

    if st.session_state.get("source_auto_selected", False):
        st.session_state.source_id = ""
        st.session_state.source_type = ""
        st.session_state.source_name = ""

    st.toast("Fişe eklendi.")


def remove_from_receipt(index):
    if 0 <= index < len(st.session_state.receipt_items):
        st.session_state.receipt_items.pop(index)

    if st.session_state.get("source_auto_selected", False):
        st.session_state.source_id = ""
        st.session_state.source_type = ""
        st.session_state.source_name = ""

    for i, item in enumerate(st.session_state.receipt_items, start=1):
        item["line_id"] = "L" + str(i).zfill(3)


def update_receipt_prices_from_inputs():
    for i, item in enumerate(st.session_state.receipt_items):
        price_key = f"receipt_price_{i}_{item['product_id']}"
        note_key = f"receipt_note_{i}_{item['product_id']}"

        item["fiyat"] = clean_cell(st.session_state.get(price_key, item.get("fiyat", "")))
        item["not"] = clean_cell(st.session_state.get(note_key, item.get("not", "")))


def save_receipt():
    update_receipt_prices_from_inputs()

    if not st.session_state.source_name:
        st.error("Kaydetmeden önce önerilen fiş kaynağını onayla, değiştir ya da elle yaz.")
        return

    if not st.session_state.receipt_items:
        st.error("Fişte ürün yok.")
        return

    valid_items = []
    invalid_items = []

    for item in st.session_state.receipt_items:
        price = parse_price(item.get("fiyat", ""))
        if price is None:
            invalid_items.append(item)
        else:
            item_copy = item.copy()
            item_copy["fiyat"] = price
            valid_items.append(item_copy)

    if invalid_items:
        st.error("Fiyatı boş veya hatalı ürün var. Kaydetmeden önce tüm fiyatları gir.")
        return

    receipt_id = "R" + datetime.now().strftime("%Y%m%d%H%M%S") + "_" + uuid.uuid4().hex[:6]
    tarih, saat = get_today_strings()

    header_row = {
        "receipt_id": receipt_id,
        "tarih": tarih,
        "saat": saat,
        "source_id": st.session_state.source_id,
        "source_type": st.session_state.source_type,
        "source_name": st.session_state.source_name,
        "konum_lat": st.session_state.location_lat,
        "konum_lon": st.session_state.location_lon,
        "konum_dogrulandi": st.session_state.location_confirmed,
        "toplam_kalem": len(valid_items),
        "not": st.session_state.receipt_note,
    }

    line_rows = []

    for item in valid_items:
        line_rows.append({
            "receipt_id": receipt_id,
            "line_id": item["line_id"],
            "tarih": tarih,
            "saat": saat,
            "source_id": st.session_state.source_id,
            "source_type": st.session_state.source_type,
            "source_name": st.session_state.source_name,
            "product_id": item["product_id"],
            "urun_adi": item["urun_adi"],
            "marka": item["marka"],
            "model": item["model"],
            "varyant": item["varyant"],
            "birim": item["birim"],
            "fiyat": item["fiyat"],
            "konum_lat": st.session_state.location_lat,
            "konum_lon": st.session_state.location_lon,
            "not": item.get("not", ""),
        })

    append_csv(RECEIPT_HEADER_FILE, [header_row], RECEIPT_HEADER_COLUMNS)
    append_csv(PRICE_RECORDS_FILE, line_rows, PRICE_RECORD_COLUMNS)

    st.session_state.last_save_status = f"Fiş kaydedildi: {receipt_id}"
    st.session_state.receipt_items = []
    st.session_state.clear_receipt_inputs_next_run = True

    st.success(st.session_state.last_save_status)


# =========================================================
# 5. ARAMA
# =========================================================

def search_products(query, limit=40):
    query_norm = normalize_for_search(query)

    if len(query_norm) < 3 or products_df.empty:
        return pd.DataFrame(columns=products_df.columns)

    tokens = query_norm.split()

    result = products_df[
        products_df["search_text"].apply(
            lambda text: all(token in text for token in tokens)
        )
    ].copy()

    if result.empty and len(tokens) > 1:
        result = products_df[
            products_df["search_text"].apply(
                lambda text: any(token in text for token in tokens)
            )
        ].copy()

    if result.empty:
        return result

    def score_row(row):
        main_text = normalize_for_search(compact_join([
            row.get("marka", ""),
            row.get("model", ""),
            row.get("urun_adi", ""),
        ]))

        path_text = normalize_for_search(row.get("ui_path", ""))

        score = 0

        if query_norm in main_text:
            score += 100

        if query_norm in path_text:
            score += 50

        for token in tokens:
            if token in main_text:
                score += 20
            if token in path_text:
                score += 8

        return score

    result["search_score"] = result.apply(score_row, axis=1)
    result = result.sort_values("search_score", ascending=False).head(limit)

    return result


# =========================================================
# 6. CSS
# =========================================================

st.markdown("""
<style>
.main-card {
    border: 1px solid #e2e8f0;
    border-radius: 18px;
    padding: 14px;
    background: #ffffff;
    margin-bottom: 12px;
}

.small-muted {
    color: #64748b;
    font-size: 12px;
}

.product-title {
    color: #0f172a;
    font-size: 15px;
    font-weight: 800;
}

.product-path {
    color: #64748b;
    font-size: 12px;
}

.receipt-box {
    border: 2px solid #0f172a;
    border-radius: 18px;
    padding: 14px;
    background: #f8fafc;
    margin-bottom: 16px;
}

.receipt-item {
    border-bottom: 1px solid #e2e8f0;
    padding: 8px 0;
}

.stButton>button {
    min-height: 48px;
    border-radius: 12px;
    font-weight: 700;
}

div[data-testid="stTextInput"] input {
    min-height: 42px;
}
</style>
""", unsafe_allow_html=True)


# =========================================================
# 7. SESSION STATE
# =========================================================

def init_state():
    defaults = {
        "step": "location",
        "location_lat": "",
        "location_lon": "",
        "location_confirmed": False,

        "source_id": "",
        "source_type": "",
        "source_name": "",
        "source_auto_selected": False,

        "receipt_items": [],
        "receipt_note": "",
        "last_save_status": "",

        "product_list_limit": 12,
        "search_query": "",
        "search_limit": 8,
        "clear_search_query_next_run": False,
        "clear_receipt_inputs_next_run": False,
        "source_group_filter": "Tümü",
    }

    for i in range(1, 6):
        defaults[f"level_{i}"] = ""

    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


init_state()


# =========================================================
# 8. ÜST BİLGİ
# =========================================================

st.title("🧾 FiyatCep")
st.caption("Data paketi: v9 + karşılaştırma v1")

if st.session_state.source_name:
    st.caption(
        f"Fiş kaynağı: {st.session_state.source_name}"
        + (f" / {st.session_state.source_type}" if st.session_state.source_type else "")
    )
else:
    st.caption("Önce ürünleri seç. Fişi kaydetmeden önce fiyat kaynağını seçeceksin.")

if st.session_state.last_save_status:
    st.success(st.session_state.last_save_status)


# =========================================================
# 9. FİŞ PANELİ
# =========================================================

def apply_auto_source_if_needed():
    if not st.session_state.receipt_items:
        return

    if st.session_state.source_name and not st.session_state.get("source_auto_selected", False):
        return

    suggestion = get_best_source_suggestion()

    if suggestion is None:
        return

    suggested_id = clean_cell(suggestion.get("source_id", ""))

    if st.session_state.source_id == suggested_id and st.session_state.source_name:
        return

    st.session_state.source_id = suggested_id
    st.session_state.source_type = clean_cell(suggestion.get("source_type", ""))
    st.session_state.source_name = clean_cell(suggestion.get("source_name", ""))
    st.session_state.source_auto_selected = True


def render_receipt_panel():
    st.markdown('<div class="receipt-box">', unsafe_allow_html=True)

    st.subheader("Fiş / Adisyon")

    # Streamlit kuralı:
    # Bir widget aynı çalıştırmada oluşturulduktan sonra onun session_state key'i değiştirilemez.
    # Bu yüzden fiş notu ve fiyat input temizliği, widgetlar oluşturulmadan önce yapılır.
    if st.session_state.get("clear_receipt_inputs_next_run", False):
        st.session_state.receipt_note = ""

        for key in list(st.session_state.keys()):
            if key.startswith("receipt_price_") or key.startswith("receipt_note_"):
                del st.session_state[key]

        st.session_state.clear_receipt_inputs_next_run = False

    apply_auto_source_if_needed()

    if not st.session_state.source_name:
        st.caption("Kaynak henüz seçilmedi. Önce ürün ekle; sonra kaynak önerisi otomatik gelecek.")
    else:
        csrc1, csrc2 = st.columns([3, 1])
        auto_note = "Otomatik öneri" if st.session_state.get("source_auto_selected", False) else "Seçili kaynak"
        csrc1.markdown(
            f"**{st.session_state.source_name}**  \\n"
            f"<small>{st.session_state.source_type} • {auto_note}</small>",
            unsafe_allow_html=True
        )
        if csrc2.button("Değiştir", key="change_source_from_receipt"):
            st.session_state.step = "source_smart"
            st.rerun()

    if not st.session_state.receipt_items:
        st.info("Fişe henüz ürün eklenmedi.")
    else:
        update_receipt_prices_from_inputs()

        total = 0.0
        all_valid = True

        for i, item in enumerate(st.session_state.receipt_items):
            price_key = f"receipt_price_{i}_{item['product_id']}"
            note_key = f"receipt_note_{i}_{item['product_id']}"

            st.markdown('<div class="receipt-item">', unsafe_allow_html=True)
            c1, c2 = st.columns([4, 1])

            c1.markdown(f"**{i + 1}. {item['title']}**")
            c1.caption(f"{item['birim']} • {item['path']}")

            if c2.button("Sil", key=safe_key("remove_receipt", item["product_id"], i)):
                remove_from_receipt(i)
                st.rerun()

            p1, p2 = st.columns([2, 3])

            p1.text_input(
                "Fiyat",
                value=item.get("fiyat", ""),
                key=price_key,
                placeholder="Örn: 1299,90",
            )

            p2.text_input(
                "Not",
                value=item.get("not", ""),
                key=note_key,
                placeholder="Opsiyonel",
            )

            parsed = parse_price(st.session_state.get(price_key, ""))

            if parsed is None:
                all_valid = False
            else:
                total += parsed

            st.markdown('</div>', unsafe_allow_html=True)

        st.markdown(f"### Toplam: {format_price(str(total))} ₺")

        st.text_input(
            "Fiş notu",
            key="receipt_note",
            placeholder="Opsiyonel fiş notu",
        )

        s1, s2, s3 = st.columns(3)

        if s1.button("✅ FİŞİ KAYDET", use_container_width=True, type="primary"):
            save_receipt()
            st.rerun()

        if s2.button("📊 En Ucuz", use_container_width=True):
            st.session_state.step = "compare_prices"
            st.rerun()

        if s3.button("🧹 Temizle", use_container_width=True):
            st.session_state.receipt_items = []
            st.session_state.clear_receipt_inputs_next_run = True
            st.rerun()

        if not all_valid:
            st.caption("Kaydetmek için tüm ürünlerin fiyatı geçerli olmalı.")

    st.markdown('</div>', unsafe_allow_html=True)


# =========================================================
# 10. EKRANLAR
# =========================================================

def render_location_screen():
    st.subheader("Konum")

    if HAS_MAP:
        m = folium.Map(location=[41.0082, 28.9784], zoom_start=12)
        st_folium(m, height=240, width=700)
    else:
        st.info("Harita paketi kurulu değil. Konum alanı test modunda çalışıyor.")

    st.caption("Bu ekranda şimdilik konum onayı alınıyor. Gerçek GPS entegrasyonu ayrıca eklenebilir.")

    if st.button("Konumu Onayla ve Başla", use_container_width=True, type="primary"):
        st.session_state.location_confirmed = True
        st.session_state.step = "product_tree"
        st.rerun()


def render_source_type_screen():
    st.subheader("Fiş kaynağı seç")
    st.caption("Bu seçim ürün ağacını açmak için değil, fişi kaydederken fiyatın nereden alındığını belirtmek içindir.")

    if st.button("⬅️ Ürünlere Dön", use_container_width=True):
        st.session_state.step = "product_tree"
        st.rerun()

    if sources_df.empty:
        st.warning("source_master.csv içinde kaynak yok. Elle kaynak girebilirsin.")
    else:
        source_types = [
            clean_cell(x)
            for x in sources_df["source_type"].dropna().unique()
            if clean_cell(x)
        ]

        source_type_order = {
            "Gıda Marketi": 1,
            "Pazar": 2,
            "Esnaf": 3,
            "Elektronik Marketi": 4,
            "Elektronik Market": 4,
            "Online Mağaza": 5,
            "Marka Mağazası": 6,
        }

        source_types = sorted(
            source_types,
            key=lambda x: (source_type_order.get(x, 99), normalize_for_search(x))
        )

        st.caption("Kaynak türleri source_master.csv dosyasından okunuyor.")

        cols = st.columns(2)

        for i, source_type in enumerate(source_types):
            count = len(sources_df[sources_df["source_type"] == source_type])

            if cols[i % 2].button(
                f"{source_type} ({count})",
                key=safe_key("source_type", source_type, i),
                use_container_width=True,
            ):
                st.session_state.selected_source_type = source_type
                st.session_state.source_group_filter = "Tümü"
                st.session_state.step = "source_name"
                st.rerun()

    with st.expander("Kaynağı elle yaz"):
        manual_type = st.text_input("Kaynak türü", placeholder="Örn: Yerel mağaza, bayi, pazar...")
        manual_name = st.text_input("Kaynak adı", placeholder="Örn: Kadıköy Elektronikçi...")

        if st.button("Elle Kaynağı Kullan", use_container_width=True):
            if clean_cell(manual_name):
                select_manual_source(manual_type, manual_name)
                st.rerun()
            else:
                st.error("Kaynak adı boş olamaz.")



def get_receipt_context_for_sources():
    """
    Fişe eklenen ürünlerden kaynak seçiminde kullanılacak bağlamı çıkarır.
    Amaç: Kaynak seçerken tüm marka mağazalarını göstermek yerine,
    fişteki ürünlerin sektör/kategori/markasına uygun kaynakları öne getirmek.
    """
    sectors = set()
    categories = set()
    alt_categories = set()
    product_types = set()
    brands = set()

    for item in st.session_state.receipt_items:
        for key, target_set in [
            ("sektor", sectors),
            ("ana_kategori", categories),
            ("alt_kategori", alt_categories),
            ("urun_turu", product_types),
            ("marka", brands),
        ]:
            value = clean_cell(item.get(key, ""))
            if value:
                target_set.add(value)

    return {
        "sectors": sectors,
        "categories": categories,
        "alt_categories": alt_categories,
        "product_types": product_types,
        "brands": brands,
    }


def split_scope(value):
    return [
        clean_cell(x)
        for x in str(value).split("|")
        if clean_cell(x)
    ]


def source_matches_receipt(row, context):
    if not st.session_state.receipt_items:
        return True

    source_type = clean_cell(row.get("source_type", ""))
    related_brand = clean_cell(row.get("related_brand", ""))
    sector_scope = clean_cell(row.get("sector_scope", ""))
    category_scope_values = split_scope(row.get("category_scope", ""))

    sectors = context["sectors"]
    categories = context["categories"]
    alt_categories = context["alt_categories"]
    product_types = context["product_types"]
    brands = context["brands"]

    if source_type == "Marka Mağazası":
        return related_brand in brands if related_brand else False

    if source_type in ["Elektronik Marketi", "Elektronik Market"]:
        return "Elektronik" in sectors

    if source_type == "Gıda Marketi":
        return "Gıda" in sectors

    if source_type in ["Pazar", "Esnaf"]:
        return "Gıda" in sectors

    if source_type == "Online Mağaza":
        return True

    if sector_scope:
        if sector_scope not in sectors:
            return False
    else:
        return False

    if category_scope_values:
        product_scope_values = categories | alt_categories | product_types
        return bool(set(category_scope_values) & product_scope_values)

    return True


def source_relevance_score(row, context):
    score = 0

    if not st.session_state.receipt_items:
        return score

    source_type = clean_cell(row.get("source_type", ""))
    related_brand = clean_cell(row.get("related_brand", ""))
    sector_scope = clean_cell(row.get("sector_scope", ""))
    category_scope_values = split_scope(row.get("category_scope", ""))

    if related_brand and related_brand in context["brands"]:
        score += 100

    if source_type == "Marka Mağazası" and related_brand in context["brands"]:
        score += 50

    if source_type == "Online Mağaza":
        score += 20

    if sector_scope and sector_scope in context["sectors"]:
        score += 30

    product_scope_values = context["categories"] | context["alt_categories"] | context["product_types"]

    if category_scope_values:
        score += 15 * len(set(category_scope_values) & product_scope_values)

    product_count = pd.to_numeric(row.get("product_count", "0"), errors="coerce")
    if pd.isna(product_count):
        product_count = 0

    score += min(float(product_count), 1000) / 1000

    return score



def get_smart_source_candidates():
    """
    Fişteki ürünlere göre tüm kaynak türleri arasından uygun kaynakları getirir.
    Örnek:
    - Apple ürün varsa Apple Marka Mağazası
    - Elektronik ürün varsa Elektronik Marketi
    - Gıda ürün varsa Gıda Marketi
    - Online mağazalar genel alternatif olarak görünür
    """
    context = get_receipt_context_for_sources()

    if sources_df.empty:
        return pd.DataFrame(columns=sources_df.columns)

    candidates = sources_df.copy()

    if st.session_state.receipt_items:
        candidates = candidates[
            candidates.apply(lambda row: source_matches_receipt(row, context), axis=1)
        ].copy()

    if not candidates.empty:
        candidates["_score"] = candidates.apply(lambda row: source_relevance_score(row, context), axis=1)
        candidates["_pc"] = pd.to_numeric(candidates.get("product_count", "0"), errors="coerce").fillna(0)

        type_order = {
            "Marka Mağazası": 1,
            "Elektronik Marketi": 2,
            "Elektronik Market": 2,
            "Gıda Marketi": 2,
            "Online Mağaza": 3,
            "Pazar": 4,
            "Esnaf": 5,
        }

        candidates["_type_order"] = candidates["source_type"].map(type_order).fillna(99)
        candidates = candidates.sort_values(
            ["_score", "_type_order", "_pc", "source_name"],
            ascending=[False, True, False, True]
        )
        candidates = candidates.drop(columns=["_score", "_pc", "_type_order"])

    return candidates


def get_best_source_suggestion():
    candidates = get_smart_source_candidates()

    if candidates.empty:
        return None

    return candidates.iloc[0]


def confirm_source_row(row):
    st.session_state.source_id = clean_cell(row.get("source_id", ""))
    st.session_state.source_type = clean_cell(row.get("source_type", ""))
    st.session_state.source_name = clean_cell(row.get("source_name", ""))
    st.session_state.source_auto_selected = False
    st.session_state.step = "product_tree"


def render_smart_source_screen():
    st.subheader("Fiş kaynağı")

    if st.button("⬅️ Ürünlere Dön", use_container_width=True):
        st.session_state.step = "product_tree"
        st.rerun()

    candidates = get_smart_source_candidates()

    if candidates.empty:
        st.warning("Fişteki ürünlere göre kaynak önerisi bulunamadı. Kaynağı elle yazabilirsin.")
    else:
        if st.session_state.receipt_items:
            st.caption("Fişteki ürünlerin marka/kategorisine göre önerilen kaynaklar.")
        else:
            st.caption("Fişte ürün yoksa genel kaynak listesi gösterilir.")

        query = st.text_input("Kaynak ara", placeholder="Örn: Apple, MediaMarkt, Trendyol...")

        if clean_cell(query):
            q = normalize_for_search(query)
            candidates = candidates[
                candidates["source_name"].apply(lambda x: q in normalize_for_search(x))
                | candidates["source_type"].apply(lambda x: q in normalize_for_search(x))
            ]

        st.caption(f"{len(candidates)} kaynak")

        for i, (_, row) in enumerate(candidates.iterrows()):
            c1, c2 = st.columns([3, 1])

            c1.markdown(f"**{row['source_name']}**")
            c1.caption(compact_join([
                row.get("source_type", ""),
                row.get("sector_scope", ""),
                row.get("category_scope", ""),
                f"{row.get('product_count', '')} ürün" if clean_cell(row.get("product_count", "")) else "",
            ], sep=" • "))

            if c2.button("Seç", key=safe_key("smart_source_select", row["source_id"], i), use_container_width=True):
                confirm_source_row(row)
                st.rerun()

            st.divider()

    with st.expander("Kaynağı elle yaz"):
        manual_type = st.text_input(
            "Kaynak türü",
            key="manual_source_type_smart",
            placeholder="Örn: Yerel mağaza, bayi, pazar..."
        )
        manual_name = st.text_input(
            "Kaynak adı",
            key="manual_source_name_smart",
            placeholder="Örn: Kadıköy Elektronikçi..."
        )

        if st.button("Elle Kaynağı Kullan", use_container_width=True, key="manual_source_use_smart"):
            if clean_cell(manual_name):
                select_manual_source(manual_type, manual_name)
                st.rerun()
            else:
                st.error("Kaynak adı boş olamaz.")

    # Eski kaynak türü menüsü bilinçli olarak gizlendi.
    # Kaynak değiştirme artık fişteki ürünlere göre daraltılmış liste üzerinden yapılır.


def render_source_name_screen():
    selected_type = clean_cell(st.session_state.get("selected_source_type", ""))

    st.subheader(selected_type or "Kaynak")

    filtered = sources_df[sources_df["source_type"] == selected_type].copy()

    context = get_receipt_context_for_sources()

    if filtered.empty:
        st.warning("Bu kaynak türü altında kayıt yok.")
    else:
        if st.session_state.receipt_items:
            before_count = len(filtered)
            filtered = filtered[
                filtered.apply(lambda row: source_matches_receipt(row, context), axis=1)
            ].copy()

            if not filtered.empty:
                st.caption(
                    f"Fişteki ürünlere göre uygun kaynaklar gösteriliyor. "
                    f"{len(filtered)} / {before_count}"
                )
            else:
                st.warning("Fişteki ürünlere uygun kaynak bulunamadı. İstersen kaynağı elle yazabilirsin.")
                filtered = sources_df[sources_df["source_type"] == selected_type].copy()
                st.caption("Uygun kaynak bulunamadığı için bu türdeki tüm kaynaklar geçici olarak gösteriliyor.")
        else:
            st.caption("Fişte ürün yoksa kaynaklar genel liste olarak gösterilir.")

        query = st.text_input("Kaynak ara", placeholder="Marka / kaynak adı yaz...")

        if clean_cell(query):
            q = normalize_for_search(query)
            filtered = filtered[
                filtered["source_name"].apply(lambda x: q in normalize_for_search(x))
            ]

        if not filtered.empty:
            filtered["_score"] = filtered.apply(lambda row: source_relevance_score(row, context), axis=1)
            filtered["_pc"] = pd.to_numeric(filtered.get("product_count", "0"), errors="coerce").fillna(0)
            filtered = filtered.sort_values(["_score", "_pc", "source_name"], ascending=[False, False, True])
            filtered = filtered.drop(columns=["_score", "_pc"])

        st.caption(f"{len(filtered)} kaynak")

        for i, (_, row) in enumerate(filtered.iterrows()):
            c1, c2 = st.columns([3, 1])

            c1.markdown(f"**{row['source_name']}**")
            c1.caption(compact_join([
                row.get("source_type", ""),
                row.get("sector_scope", ""),
                row.get("category_scope", ""),
                f"{row.get('product_count', '')} ürün" if clean_cell(row.get("product_count", "")) else "",
            ], sep=" • "))

            if c2.button("Seç", key=safe_key("select_source", row["source_id"], i), use_container_width=True):
                select_source_from_row(row)
                st.rerun()

            st.divider()

    with st.expander("Kaynağı elle yaz"):
        manual_type = st.text_input(
            "Kaynak türü",
            value=selected_type,
            key="manual_source_type_from_name",
            placeholder="Örn: Yerel mağaza, bayi, pazar..."
        )
        manual_name = st.text_input(
            "Kaynak adı",
            key="manual_source_name_from_name",
            placeholder="Örn: Kadıköy Elektronikçi..."
        )

        if st.button("Elle Kaynağı Kullan", use_container_width=True, key="manual_source_use_from_name"):
            if clean_cell(manual_name):
                select_manual_source(manual_type, manual_name)
                st.rerun()
            else:
                st.error("Kaynak adı boş olamaz.")

    cback1, cback2 = st.columns(2)

    if cback1.button("⬅️ Kaynak Türüne Dön", use_container_width=True):
        st.session_state.step = "source_type"
        st.rerun()

    if cback2.button("Ürünlere Dön", use_container_width=True):
        st.session_state.step = "product_tree"
        st.rerun()



def render_tree_breadcrumb():
    selected_parts = []

    for i in range(1, 6):
        value = clean_cell(st.session_state.get(f"level_{i}", ""))
        if value:
            selected_parts.append(value)

    if selected_parts:
        st.caption(" > ".join(selected_parts))


def render_product_tree_screen():
    st.subheader("Ürün seç")
    render_tree_breadcrumb()

    if any(clean_cell(st.session_state.get(f"level_{i}", "")) for i in range(1, 6)):
        n1, n2 = st.columns(2)

        if n1.button("⬅️ Bir üst kategoriye dön", use_container_width=True):
            go_up_one_level()
            st.rerun()

        if n2.button("🏠 Başa dön", use_container_width=True):
            reset_tree(1)
            st.rerun()

    level_no, level_col, options = get_next_level_options()
    filtered_products = get_filtered_products()

    # İlk görünen alan her zaman ürün ağacı / ana kategoriler olsun.
    if level_col and options:
        if level_no == 1:
            st.markdown("#### Ana Kategoriler")
        else:
            st.markdown("#### Seçimle ilerle")

        cols_count = 2 if len(options) < 8 else 3
        cols = st.columns(cols_count)

        for i, option in enumerate(options):
            count = len(filtered_products[filtered_products[level_col] == option])
            label = f"{option} ({count})"

            if cols[i % cols_count].button(
                label,
                key=safe_key(f"level_{level_no}", option, i),
                use_container_width=True,
            ):
                st.session_state[f"level_{level_no}"] = option
                reset_tree(level_no + 1)
                st.rerun()

    # Seçim yeterince daraldıysa veya tüm seviyeler seçildiyse ürünleri göster.
    product_count = len(filtered_products)

    show_products = (
        product_count <= 60 or
        all(clean_cell(st.session_state.get(f"level_{i}", "")) for i in range(1, 6)) or
        (level_col is None)
    )

    if show_products:
        st.markdown("#### Ürünler")
        render_product_list(filtered_products)
    else:
        st.info(f"{product_count} ürün var. Listeyi açmak yerine yukarıdaki seçimlerle daralt.")

    st.markdown("---")

    with st.expander("🔎 Bulamazsan ara", expanded=False):
        render_quick_search()

    st.markdown("---")
    render_receipt_panel()


def render_product_list(df):
    if df.empty:
        st.warning("Bu seçimde ürün yok.")
        return

    df = df.copy()
    df["_display_order"] = df.apply(product_order_score, axis=1)
    df["_name_order"] = df["urun_adi"].apply(normalize_for_search)
    df = df.sort_values(["_display_order", "_name_order"])

    limit = int(st.session_state.product_list_limit)
    visible = df.head(limit)

    st.caption(f"Gösterilen: {len(visible)} / {len(df)}")

    for i, (_, row) in enumerate(visible.iterrows()):
        product_id = row["product_id"]
        title = format_product_title(row)
        subtitle = format_product_subtitle(row)
        specs = get_specs_preview(product_id)
        ref = get_reference_preview(product_id)

        st.markdown('<div class="main-card">', unsafe_allow_html=True)

        c1, c2 = st.columns([4, 1])

        c1.markdown(f'<div class="product-title">{title}</div>', unsafe_allow_html=True)
        c1.markdown(f'<div class="product-path">{subtitle}</div>', unsafe_allow_html=True)

        if specs:
            c1.caption(specs)

        if ref:
            c1.caption(f"Referans: {ref}")

        if c2.button("Ekle", key=safe_key("add_product", product_id, i), use_container_width=True):
            add_to_receipt(row)
            st.rerun()

        st.markdown('</div>', unsafe_allow_html=True)

    if len(df) > limit:
        if st.button("➕ Daha fazla ürün göster", use_container_width=True):
            st.session_state.product_list_limit = min(limit + 12, 72)
            st.rerun()


def render_quick_search():
    st.markdown("#### Bulamazsan ara")

    # Streamlit kuralı:
    # Bir widget aynı çalıştırmada oluşturulduktan sonra onun session_state key'i değiştirilemez.
    # Bu yüzden temizleme işlemini bir sonraki rerun'ın başında yapıyoruz.
    if st.session_state.get("clear_search_query_next_run", False):
        st.session_state.search_query = ""
        st.session_state.search_limit = 8
        st.session_state.clear_search_query_next_run = False

    query = st.text_input(
        "Ürün ara",
        key="search_query",
        placeholder="Örn: iPhone 128, Bosch buzdolabı, süt, domates...",
    )

    if not clean_cell(query) or len(normalize_for_search(query)) < 3:
        st.caption("Ana yöntem seçimle ilerlemek. Arama sadece yedek.")
        return

    results = search_products(query, limit=40)

    if results.empty:
        st.warning("Aramada sonuç yok.")
        return

    limit = int(st.session_state.search_limit)
    visible = results.head(limit)

    st.caption(f"Arama sonucu: {len(visible)} / {len(results)}")

    for i, (_, row) in enumerate(visible.iterrows()):
        product_id = row["product_id"]
        title = format_product_title(row)
        subtitle = format_product_subtitle(row)

        c1, c2 = st.columns([4, 1])

        c1.markdown(f"**{title}**")
        c1.caption(subtitle)

        if c2.button("Ekle", key=safe_key("search_add", product_id, i), use_container_width=True):
            add_to_receipt(row)
            st.session_state.clear_search_query_next_run = True
            st.rerun()

        st.divider()

    if len(results) > limit:
        if st.button("Aramada daha fazla göster", use_container_width=True):
            st.session_state.search_limit = min(limit + 8, 40)
            st.rerun()

    if st.button("Aramayı temizle", use_container_width=True):
        st.session_state.clear_search_query_next_run = True
        st.rerun()



# =========================================================
# 11. EN UCUZ / DURAK ÖNERİSİ
# =========================================================

def render_compare_screen():
    st.subheader("📊 En Ucuz / Durak Önerisi")

    if st.button("⬅️ Ürünlere Dön", use_container_width=True):
        st.session_state.step = "product_tree"
        st.rerun()

    current_df = make_current_receipt_df()
    saved_df = read_saved_price_records()

    if current_df.empty:
        st.info("Önce fişe ürün ekle. Sonra bu ekrandan geçmiş kayıtlarla karşılaştırma yapacağız.")
        return

    if saved_df.empty:
        st.warning("Henüz geçmiş fiyat kaydı yok. Birkaç fiş kaydettikten sonra karşılaştırma çalışır.")
        return

    cheapest_df, stop_df, single_stop_df = compute_cheapest_plan(current_df, saved_df)

    if cheapest_df.empty:
        st.warning("Fişteki ürünler için geçmiş fiyat bulunamadı. Aynı ürünlerden fiyat kaydı yaptıkça öneri oluşacak.")
        return

    total_mixed = round(float(cheapest_df["en_ucuz_fiyat"].sum()), 2)
    found_count = len(cheapest_df)
    total_count = len(current_df)

    st.markdown(f"### Karışık en ucuz toplam: {format_price(str(total_mixed))} ₺")
    st.caption(f"{found_count} / {total_count} ürün için geçmiş fiyat bulundu.")

    st.markdown("#### Ürün bazında en ucuz")
    for i, row in cheapest_df.iterrows():
        st.markdown(
            f"**{row['urun']}**  \n"
            f"{format_price(str(row['en_ucuz_fiyat']))} ₺ • {row['source_name']} • {row['tarih']}"
        )
        st.divider()

    if not stop_df.empty:
        st.markdown("#### Karışık alışveriş durakları")
        st.caption("Her ürünü en ucuz görünen kaynaktan alırsan uğrayacağın duraklar.")

        for _, row in stop_df.iterrows():
            st.markdown(
                f"**{row['source_name']}**  \n"
                f"{row['urun_sayisi']} ürün • Toplam: {format_price(str(row['toplam']))} ₺"
            )
            st.caption(row["urunler"])

    if not single_stop_df.empty:
        st.markdown("#### Tek durak alternatifi")
        st.caption("Tek yerde mümkün olduğunca çok ürünü almak istersen.")

        best_single = single_stop_df.iloc[0]

        st.success(
            f"Öneri: {best_single['source_name']} • "
            f"{int(best_single['bulunan_urun'])}/{int(best_single['toplam_urun'])} ürün • "
            f"Toplam: {format_price(str(best_single['toplam']))} ₺"
        )

        with st.expander("Diğer tek durak seçenekleri"):
            for _, row in single_stop_df.head(10).iterrows():
                st.markdown(
                    f"**{row['source_name']}** — "
                    f"{int(row['bulunan_urun'])}/{int(row['toplam_urun'])} ürün, "
                    f"eksik: {int(row['eksik_urun'])}, "
                    f"toplam: {format_price(str(row['toplam']))} ₺"
                )

    st.markdown("---")
    st.caption("Not: Bu öneri sadece kaydettiğin geçmiş fiyatlara göre çalışır. Güncel piyasa fiyatı garantisi değildir.")


# =========================================================
# 11. ANA ROUTER
# =========================================================

if products_df.empty:
    st.error("products_master_clean.csv bulunamadı veya boş.")
    st.stop()

if st.session_state.step == "location":
    render_location_screen()

elif st.session_state.step == "source_smart":
    render_smart_source_screen()

elif st.session_state.step == "source_type":
    render_source_type_screen()

elif st.session_state.step == "source_name":
    render_source_name_screen()

elif st.session_state.step == "product_tree":
    render_product_tree_screen()

elif st.session_state.step == "compare_prices":
    render_compare_screen()

else:
    st.session_state.step = "location"
    st.rerun()
